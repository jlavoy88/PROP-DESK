import React, { useState, useEffect, useMemo } from "react";
import {
  Plus, Pencil, Trash2, X, TrendingUp, TrendingDown, ShieldAlert, ShieldCheck,
  Wallet, CalendarDays, Layers, AlertTriangle, CheckCircle2, XCircle,
  Banknote, Activity, Lock, Info
} from "lucide-react";

const SUPA_URL = "https://grrkcqwbwxnengvvuyvw.supabase.co";
const SUPA_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdycmtjcXdid3huZW5ndnZ1eXZ3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA1NTU2NDgsImV4cCI6MjA5NjEzMTY0OH0.LKl3R-1brq7EdHMReFs53UJBT4wqgULZecCZrn_u3z0";
const sb = (typeof window !== "undefined" && window.supabase) ? window.supabase.createClient(SUPA_URL, SUPA_KEY) : null;
const LOGO_SRC = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALAAAABlCAYAAADtRGnCAAAACXBIWXMAAC4jAAAuIwF4pT92AAAPyklEQVR4nO2df2hb19nHv1dX9r2OVCyImQwO2CweVl57yAW/b1TiYod6VKwZyahhGVFpug7iQSEuC+9rmEc95jH/YbAKGfFY/khYYS3VqMMCVpkg2qKCS8MbZXUWmSkkfqtg5UWlCpGjX1e6+0OWf8iS9eu5P+TcDxywda/POVf+3uc+55znPJcRRRHyYpS7QY19S4zRKd0FDY160ASs0dDILODVTnnb09jvyCzgX8zK257GfoeRbxAnsEBnBHhikqlBjX2PrIO4/x3QxKtBx3f9gKwuxF/t8rWlsf857gFkcyGirTn3IaOXoTGNfQ+XAB6ZAD4pkwW+MaKJV4OO/1wC+CQgmwtxY0SedjSeD77nzv8kk4A9mv+rQcjL3vxPMgj48jng/7qkb0fj+eCUC/ivz/O/ySBgzfpqUDLs2f6bDLMQ5qfAulHiRjSeG+52AZ2r+d9ksMCaeDWo+Mn8dvECWjSaRkOxNXjLI7ELEW0FDkUlbEDjuSJkAkxPtn8isQXWlo81KNkpXkByC/wfD7QpNA06YkzhJxJa4JUeTbwadHCJYp9KKGCvtnysQcjuARwASBhgo/m/kYgIt1tAOCwiFsv9HovljrW1AUYjg/5+Hbq7dejuZsDzu56QGpvIJGC/32998cUX/VT1/elPzTh9uomqOnISCREulwCXKwOPJ4P19frr5DjAbmfhcnHQ6xtH1AsLAn74w6Qkdd+799qCxbL7c3IXwu12k1rekRH1RmEGAlm0tT3DG2+kcO0ajXgBIJkErl3LwGKJ48qVNARB/ak05ufTGB2VRrxmszlssVhWih0jF7DX6x2mqstqZdDWpj4L5PdncOpUAkeOxMlEW4z790W89VYKfX1xeL0Z6Rqqk8nJFH72sxQyEnXRbre7Sx0jn0ZjGIaswsVFDna7OiywIIiYmUljejqNpDSGpixHj+qwsMChvV0dC6ixmIgXXngmeTtra2vt7e3tj4sdU7WA4/EDqhjY+P0ZnD2bxJ07yj/Ke3oYeL284iIOh7Ow2xOSfye9vb3Ly8vL3y11XB23cgnUIF4AGBiQ/h9VKSsrIoaHE4jFlOtPIJCV7TsZGRnx7HWcVMDRaLSVsj6licVEjI4mJPPtamVlJdcvpbDZ4nj0SJ4baC//FyAW8IULF8gy77QqeCssL2fQ3r6OF154hj//WWXq3eDTT7MIh7Oytul0psAw63iyKyJBGoaGhrx2u/3Tvc4hFbDH4yFbfbPbWaqqqsZmS+Bx0SGDupiZScvW1vh4Eu++K197ADA8POwtdw6ZgIPB4OHV1dUuqvqGh5URsM9HN58rNfPzgixWeHQ0gfffFyRvp5By7gNAKGBK6wsoY4F9vgzsduV8y2pJJoEPPpBWWNGoqJgbNTAwcKvcOSTTaIIgsG1tbZEnT2hyn507p8f8PEdRVVW4XGmcPi3dhLxUfPPNAZhMtDM2fn/uZlbSlRJFsexFkVjgW7duDVCJFwBGRpRxH0ZHm3DlSrMibdeDz0d7x3k8AgYHG2McQCJgavdBKQEDgMOh3sChUiwv0/rBdntS8XFAR0dHqJLzVCfgo0d15I/DapmbaywRB4N0c7LT0+pwocotYGwiimJdZXFx8VUAIlW5cYMXRdGginL+vL6ua+noYMTFRU786qsWURQN4r/+1SIeO6Yj+67yZWhIV9d1Pn16QDx5kiXvVz1lbW3NXIn+6rbAlOGTBgNgs6lnddvp5PD229UHEx07psMnn3AIhQ7Abtfj0KHcNXV36+D18jXVKSUjIwlcu6YCs7uB1Wr1lwreKaRutVC6D4ODOtXEP+SZn69uUPfxxxx8vhacOlVcpHo9g4sXm3HwIEXvctTjcgUCWXz+ubwreuWo2H0AgYDv3r3bV28deWZm1DcDoNcziMcP4Nix0l9VRweDmzd5iKIBo6PlrSvPMzhxgs4KDwxU/29cWBBgNK7jyJE4WT8o4DguMTU1NVXp+ep5XgPo71du9mEveJ6B280XFfErr+jg97dgcLC6vlPusujrq/7fODqq/ExDMWw225LRaKy4Z6oSsJoxGnMitlp3Pq7dbr6mXSNLS3SP7WrHDZOTdDMNBgPwox/RGZ5q3AegTgEHAoGeev6+0ciLOM/cXFNNmy5dLgH379NYYKuVqTi4XRBEOBwJ/OY3dEE5bjcPni9/XqVUK+C6HLHx8XFnPX+/nZ4edQ3eStHerkM6faDm3cIWyzOsrNCIl2WB69crU09//zPSAPT89qZoFLh6lcacnzx5csFms31e/swtarbAgiCwPp9vsNa/L0TJ1bdqqVW8y8sZMvECgMPBbk7R7UUgkCUV72uvsfB4ctuaKDebVhJ9VkjNAvb5fIPr63S5fxtJwLVw8WIaNhttpNvkZPlZG58vA5uNdqZhYYGD0Zi7id1uOgFXEv9bSM0uBOX8L8vuXwEHg1n89KdJ/O1v9HOt3d172x+XKw2HI0W6i/rXv97p91Na4FK5H/aipnDKaDTa2tbWFslkaN799t57TZiaUt8ccD243QLeeSdFNljbjsEA+Hz8ntOODEM3R2YwAC5X8RQHlO1UEj5ZSE0C9Hq9w1TiBfaX9Q2FsrhwIYWPPpJuafby5eaS4k0kRDgctIkryt0sSlKTCPdz/EM9CIKIvr64pJse5+aaSuaKi0ZFnDiRwGef0bkrPT1MSfFSbu23Wq215dOrJQINhFFHc3PNiked1VO++eaAeO6cXmRZ6SO09uqH2Uzb1uuvs2I8fmDPNn/+8/qi9baXxcXFV2vRouJhUUruPqbAYonj8WN6P3c7HIc9d4p4PALp7onz5/WYnW0uO13o8dC4SRzHJWqZgQBUsJRssSjehZoIBLIYHpZevGYz4PXyJd2GDz5Iw26n9XmdzvJpXcNhurllm822xPN8TRfRmOpRmMnJXMZIKabGtpMPFLLZij+lpqdTeOMNurgGlgU+/riy2SClFzDyVO1CzMzM/E+tjTUyoVAW4+MpWbaYW60Mrlzh9hz5X76cxi9/SRPT0NHBwOPhq3oaTkzQtM1xXMJmsy15vd6hwmPt7e0l8wLnqVrAlAsYvb2NEf/gdKYwOZmWPPyQ44DJySZMTJQPEjp0iO67SyTEqvNhrK7SuA/JZJI/fvy4t9ixS5cujZEKOJFIcJTxD40wgFtaysiWUml5uaXs6loeyrHD118DX38trS9fC5VEplX1LXi93uFkMkkWPKfmBYxoVMTYWBIvvSR9pp7Dhxn85S9cxeIFgK6u/T986e7uvl/unKqWkvv7+2/fuXOnv65ebTA0pIPX20JRFSmBQFaWbTYcB4yP6zEzU3sGIsplXDVSydJyxbdxJBI5SCVeQH3WN5EQMTGRRF+f9OI9c4ZFINBSl3j3OyzLVpT0rWIfeD9l3ynk+vVc4A3VwGQvbt9Wb1yBmqgksR9QhQvR1dX1gCp96tGjOll2IBuNwMBAcbEIgginM42pKWlnF8xmBtPTTTh7Vk/+zrf97ELcvHlzcHBw8LOyJ1ay3nzv3r0eqCBbS7XlzBm25Dp+by8jefsGA8SnT/eOJ6in9PRIfw1KFIPB8DSdTrNksRDU7oNcFHNTIhERExMp3L0rrbvAcYDDocfsLN0UHM8DExNbTy6LRYeVFfVk1KFiZGTEo9frK7uwSlR+8uTJT6CCO7PasrbWssNiffklLx48qHy/ai2vvrozBxplNJiayqVLl85VGo0me/ikXOX8ef2uR64UifXkLLdv70x8+MUXvOJ9oi6dnZ0Pqgmn3Lez4YWrfLGYSJpMRAkKZy+qWfhoFKoN7Nl/38AGhamevN6MKvLeUmIyMTCble4FLeSZeWKxmKH27ihHftt3Hsrt32qilrxoaoVlWYE8M8/k5OR07V1SD7/7nfyviaKkVOYij0f65fhYTITJ9IzkCXb48OFgMBj8Tv015Sh7+1Ju4JQLJd/yKRVKvTcPoHW/qrWw5dhTwKFQqGNlZcVC2aAcNEKYZrUoeU1Ue9+A+nZfFGNPATfqAoaS1koKWFbZa6IUMLUF3nOOzWw2r0EFc4PVlMOHmV3zv7/9bZPi/aqnvPdek2TL0ZUUymupZo63rnlgv99vffz4cXup42ql2PIxpQVRgv32RKGkpIAb1X0o9BUTCRE+X+MuYBgMuZff7AdaW1uj5JUWM8vxeJwzGAxPoYLHZzXl6NHd70tr9HgBpTMXXbrUTHYt1cQ41OVCLC0t2Shz/8pFsZF6o7sPIyPKWl81z0AAJRYyQqFg99BQ4z22isU/mEwMhoYaY/t+IUYj0NenrP8rCLn9i/XS1mb1d3V1rRJ0aQcldmT8fQj4vpe6MY3nmfmzgOMqda0lBPzyF8DtAerGNJ5XvhMAbh+RouYSzwZNvBqUvOyVqubGc3Q1GpDvkQ/e8pRwIYzFPtTQqAFWAB6ZgMpfH1sNRSzwP3ulaEjjeeW/p6USL1B0Gu2vDRc+qbFFJCLC48lAr88tq5tMDCIREcvLWdhsOvB8bkpREES43RlEIiJOn9Zvfp4/N4/FsvNVtn5/Bn5/Fg5HLs/F8nIGkQhgMpV6Wbt0/i9Q1IU4tQh4NBE3IFNTKczMpDffC9faCnz4IYelpSyczjSi0a3NNd3dzzZfAdbRwcDl4mCzsZiaSuFXv9pKBcCygCDk/i4SEdHfH8ejRyLu3WuBxaJDV9czrK6KOH9eD6ezWKqsqB6ocIt8DRRY4BuvaOJtTHh+Hckk8OabLGZmmnHrVhaxmIiBAR1OnEji4sWtfBJTUymEQiK++qoFhw7pwDDreOmlBL78ksf0dBpvvsmiv5/F7Gwa4XBO5B9+mMaPf5yCYeMeuH5dgMXSjNVVESwLTE+XyrQknXiBXT7wjYYM4NHAptUdG2uC05nGD36QxNhYCj5fFpnMzii9paUMbDbdrvcs58+9ejWDd99N4dEjEe+8o0colMXYWAoAMDWVe1dHMLj15LbZdLv2IMpFgYA1/7fRuXUrA4cj92C129nNd1no9cDDh1k8fJiFycTA788iGMwiHM75u729DAKB3M8PHrRgbi5nUd9/X8DYWHLz3XcLC7n68ucCQH+/brPunXwrLNV15tnmA4fNQLfkDWpIw3aftrOTweqqiD/8oRmzs2msrGxZy4MHAZeLx/HjW4m7WRbweHiMjSWxsiKis5NBOCwimcylyCr2rmWzGVhY4HclABfF7ZvYz1wBfv8W5XUWsk3Ab/8R+MghZWMa0hOJiIjFxIoyuD98mAXPY8csAy3BdqCd8A12u9km4G+vAf/fcDswNNSKdPEP29m49f5h1cSrQYt0y8fb2RCwNnjToOY47e7jEmy4EAfjAN3bhzSedwa9gPu4HC1tWGBNvBqUSLt8vB0tnFJDAuTxf4FNF0ILn9SgwhDLhU9Ku4Sc59+P70pRrWTuUwAAAABJRU5ErkJggg==";

/* ============================ FIRM PROFILES ============================ */
const SIZES = [5000, 10000, 25000, 50000, 100000, 150000, 200000, 250000, 300000, 400000];

const PROFILES = {
  "bg-instant": {
    id: "bg-instant", firm: "Blue Guardian", model: "Instant (Standard)",
    market: "Forex", kind: "instant", platform: "TradeLocker", split: 80,
    dailyLossPct: 3, maxTrailingPct: 6, guardianShieldPct: 1, maxBreaches: 2,
    firstBreachSplit: 50, minTradingDays: 5, qualifyingDayPct: 0.5,
    consistencyPct: (size) => (size >= 300000 ? 15 : 20),
    payoutCap: (size) => (size >= 300000 ? 10000 : null),
    payoutCapCount: 2,
    notes: [
      "Trailing 6% drawdown locks at your initial balance once you're up 6%.",
      "Guardian Shield auto-closes trades at 1% floating loss (soft breach).",
      "1st Shield breach → split cut to 50%. 2nd → account terminated.",
      "A day counts toward the minimum only if you close ≥0.5% profit.",
      "No news trading ±5 min. Hedging, martingale, no-SL allowed.",
      "Min withdrawal $500 (Rise) / $100 (crypto); under $2,000 is crypto-only.",
    ],
  },
  "aqua-pap": {
    id: "aqua-pap", firm: "AquaFunded", model: "Pay-After-Pass (One-Step)",
    market: "Forex", kind: "aqua", platform: "TradeLocker", split: 100,
    dailyLossPct: 3, maxTrailingPct: 6, floatingLimitPct: 2, evalTargetPct: 3,
    minTradingDays: 5, qualifyingDayPct: 0.5, consistencyPct: () => 15,
    payoutCap: (size) => (size >= 200000 ? 10000 : null),
    payoutCapCount: 2, payoutCycleDays: 14,
    notes: [
      "Trailing 6% drawdown — follows your peak and NEVER locks at initial.",
      "After a payout, the entire profit is withdrawn: balance AND trailing reset to your initial balance.",
      "Floating loss past −2% of starting balance = permanent hard breach.",
      "Daily loss limit 3% of initial, reset 00:00 UTC.",
      "Funded: 15% consistency rule, min 5 days (≥0.5% each), payouts every 14 days.",
      "No trading ±5 min around high-impact news; $100 min withdrawal via Rise.",
    ],
  },
  "e8-one": {
    id: "e8-one", firm: "E8 Markets", model: "E8 ONE (1-Step)",
    market: "Forex", kind: "e8", platform: "TradeLocker",
    split: 100, ddPct: 6, dailyPct: 3, targetPct: 6, consistencyPct: () => 40,
    notes: [
      "Dynamic drawdown trails your highest CLOSED balance and locks permanently at your initial balance once you've banked the full drawdown amount.",
      "It moves up only on closed profit — floating gains don't raise it.",
      "Daily drawdown measured from your start-of-day balance (floating or closed).",
      "40% Best-Day rule: no single day may exceed 40% of total profits.",
      "Payout requires net profit above 50% of the daily drawdown.",
      "Payout-on-demand — withdrawing ALL profit closes the account, so leave a buffer. Payouts don't reset the account.",
      "No news trading ±5 min on funded; place a trade at least every 60 days.",
    ],
  },
  "custom": { id: "custom", firm: "Custom", model: "Generic / other firm", kind: "custom", platform: "", split: 80 },
};

/* ============================ ANALYSIS ============================ */
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const money = (n) => (n < 0 ? "-" : "") + "$" + Math.abs(Math.round(n)).toLocaleString("en-US");
const moneyP = (n) => (n >= 0 ? "+" : "-") + "$" + Math.abs(Math.round(n)).toLocaleString("en-US");

function analyzeInstant(a, p) {
  const init = a.accountSize;
  const days = (a.dayLog || []).slice();
  const payouts = (a.payouts || []).slice();

  // Build a date-ordered timeline to derive current balance and peak (high watermark)
  const events = [
    ...days.map((d) => ({ date: d.date, type: "day", amount: d.amount })),
    ...payouts.map((p2) => ({ date: p2.date, type: "payout", amount: p2.amount })),
  ].sort((x, y) => (x.date < y.date ? -1 : x.date > y.date ? 1 : x.type === "day" ? -1 : 1));

  let bal = init, peak = init;
  events.forEach((e) => {
    if (e.type === "day") { bal += e.amount; if (bal > peak) peak = bal; }
    else { bal -= e.amount; } // payout withdraws from balance; peak (watermark) unaffected
  });
  const currentBalance = bal;
  const highestBalance = peak;
  const pnl = currentBalance - init;
  const pnlPct = init ? (pnl / init) * 100 : 0;

  const trailAmt = init * (p.maxTrailingPct / 100);
  const locked = peak >= init * (1 + p.maxTrailingPct / 100);
  const floor = locked ? init : peak - trailAmt;
  const cushion = currentBalance - floor;
  const cushionPct = init ? clamp((cushion / init) * 100, 0, 100) : 0;
  const ddBreached = currentBalance <= floor;

  const dailyLoss = init * (p.dailyLossPct / 100);
  const shieldTrigger = init * (p.guardianShieldPct / 100);
  const breaches = a.guardianBreaches || 0;
  const shieldDead = breaches >= p.maxBreaches;
  const effSplit = breaches >= 1 ? p.firstBreachSplit : p.split;

  // Current payout period = days logged after the most recent payout
  const lastPayoutDate = payouts.length
    ? payouts.map((x) => x.date).sort().slice(-1)[0]
    : null;
  const periodDays = lastPayoutDate ? days.filter((d) => d.date > lastPayoutDate) : days;

  const qualDayProfit = init * (p.qualifyingDayPct / 100);
  const daysDone = periodDays.filter((d) => d.amount >= qualDayProfit).length;
  const daysMet = daysDone >= p.minTradingDays;

  // consistency: biggest single day vs % of the period's total profit
  const periodProfit = periodDays.reduce((s, d) => s + d.amount, 0);
  const bigDay = periodDays.reduce((m, d) => Math.max(m, d.amount), 0);
  const consPct = p.consistencyPct(init);
  const maxDay = periodProfit > 0 ? (periodProfit * consPct) / 100 : 0;
  const consChecked = periodDays.length > 0 && periodProfit > 0;
  const consOK = !consChecked || bigDay <= maxDay;

  const cap = p.payoutCap(init);
  const taken = payouts.length;
  const cappedLeft = Math.max(0, p.payoutCapCount - taken);
  const activeCap = cap && cappedLeft > 0 ? cap : null;

  // withdrawable = profit currently sitting in the account
  const withdrawable = Math.max(0, currentBalance - init);
  const breached = ddBreached || shieldDead;
  const payable = activeCap ? Math.min(withdrawable, activeCap) : withdrawable;
  const yourShare = payable * (effSplit / 100);

  const reasons = [];
  if (ddBreached) reasons.push("Account breached (below drawdown floor)");
  if (shieldDead) reasons.push("Account terminated (2 Shield breaches)");
  if (!breached && withdrawable <= 0) reasons.push("No profit above initial to withdraw");
  if (!breached && withdrawable > 0 && !daysMet) reasons.push(`Need ${p.minTradingDays - daysDone} more qualifying day(s)`);
  if (!breached && !consOK) reasons.push(`Best day exceeds ${consPct}% — trim to ${money(maxDay)}`);

  const eligible = !breached && withdrawable > 0 && daysMet && consOK;
  let status = "FUNDED";
  if (breached) status = "BREACHED";
  else if (eligible) status = "PAYOUT READY";
  else if (breaches >= 1) status = "SHIELD WARNING";

  return { kind: "instant", currentBalance, highestBalance, pnl, pnlPct, floor, locked, cushion, cushionPct, ddBreached,
    dailyLoss, maxLossLimit: trailAmt, shieldTrigger, breaches, shieldDead, effSplit, qualDayProfit, daysDone, daysMet,
    minDays: p.minTradingDays, consPct, maxDay, consChecked, consOK, bigDay, periodProfit,
    withdrawable, activeCap, cappedLeft, payoutsTaken: taken, lastPayoutDate,
    yourShare, eligible, status, reasons };
}

function analyzeCustom(a) {
  const pnl = a.currentBalance - a.accountSize;
  const pnlPct = a.accountSize ? (pnl / a.accountSize) * 100 : 0;
  const breached = a.drawdownFloor > 0 && a.currentBalance <= a.drawdownFloor;
  const cushion = a.currentBalance - a.drawdownFloor;
  const cushionPct = a.accountSize ? clamp((cushion / a.accountSize) * 100, 0, 100) : 0;
  const targetPct = a.profitTarget > 0 ? clamp((pnl / a.profitTarget) * 100, 0, 100) : null;
  const daysMet = a.tradingDays >= a.minTradingDays;
  const isFunded = a.phase === "Funded";
  const profitMet = pnl >= (a.payoutThreshold > 0 ? a.payoutThreshold : 0.01);
  const eligible = isFunded && !breached && daysMet && profitMet && pnl > 0;
  const yourShare = pnl > 0 ? pnl * (a.profitSplit / 100) : 0;
  let status = "EVALUATION";
  if (breached) status = "BREACHED";
  else if (eligible) status = "PAYOUT READY";
  else if (isFunded) status = "FUNDED";
  const reasons = [];
  if (breached) reasons.push("Below drawdown floor");
  if (!breached && !isFunded) reasons.push("Still in evaluation");
  if (!breached && isFunded && !daysMet) reasons.push("Minimum days not met");
  if (!breached && isFunded && !profitMet) reasons.push("Profit below payout threshold");
  return { kind: "custom", currentBalance: a.currentBalance, pnl, pnlPct, breached, cushion, cushionPct, targetPct,
    daysMet, isFunded, eligible, yourShare, status, reasons, floor: a.drawdownFloor };
}

const analyze = (a) => {
  const p = PROFILES[a.profileId] || PROFILES.custom;
  if (a.profileId === "bg-instant") return analyzeInstant(a, p);
  if (a.profileId === "aqua-pap") return analyzeAqua(a, p);
  if (a.profileId === "e8-one") return analyzeE8(a, p);
  return analyzeCustom(a);
};

function analyzeE8(a, p) {
  const init = a.accountSize;
  const ddPct = a.ddPct != null ? a.ddPct : p.ddPct;
  const dailyPct = a.dailyPct != null ? a.dailyPct : p.dailyPct;
  const targetPct = a.targetPct != null ? a.targetPct : p.targetPct;
  const split = a.split != null ? a.split : p.split;
  const funded = (a.phase || "Funded") === "Funded";

  const days = (a.dayLog || []).slice();
  const payouts = (a.payouts || []).slice();
  const events = [
    ...days.map((d) => ({ date: d.date, type: "day", amount: d.amount })),
    ...payouts.map((p2) => ({ date: p2.date, type: "payout", amount: p2.amount })),
  ].sort((x, y) => (x.date < y.date ? -1 : x.date > y.date ? 1 : x.type === "day" ? -1 : 1));

  let bal = init, peak = init;
  events.forEach((e) => {
    if (e.type === "day") { bal += e.amount; if (bal > peak) peak = bal; }
    else { bal -= e.amount; }
  });
  const currentBalance = bal;
  const highestBalance = peak;
  const pnl = currentBalance - init;
  const pnlPct = init ? (pnl / init) * 100 : 0;

  // Dynamic drawdown: trails highest closed balance, locks at initial once banked the dd amount
  const trailAmt = init * (ddPct / 100);
  const locked = peak >= init + trailAmt;
  const floor = locked ? init : peak - trailAmt;
  const cushion = currentBalance - floor;
  const cushionPct = init ? clamp((cushion / init) * 100, 0, 100) : 0;
  const ddBreached = currentBalance <= floor;
  const breached = ddBreached;

  const dailyLoss = init * (dailyPct / 100);
  const minPayout = dailyLoss * 0.5; // net profit must exceed 50% of daily drawdown

  const lastPayoutDate = payouts.length ? payouts.map((x) => x.date).sort().slice(-1)[0] : null;
  const periodDays = lastPayoutDate ? days.filter((d) => d.date > lastPayoutDate) : days;
  const periodProfit = periodDays.reduce((s, d) => s + d.amount, 0);
  const bigDay = periodDays.reduce((m, d) => Math.max(m, d.amount), 0);
  const consPct = p.consistencyPct(init);
  const maxDay = periodProfit > 0 ? (periodProfit * consPct) / 100 : 0;
  const consChecked = periodDays.length > 0 && periodProfit > 0;
  const consOK = !consChecked || bigDay <= maxDay;
  const qualDayProfit = init * 0.005;
  const daysDone = periodDays.filter((d) => d.amount >= qualDayProfit).length;

  const withdrawable = Math.max(0, currentBalance - init);
  const payoutMinMet = withdrawable > minPayout;
  const yourShare = withdrawable * (split / 100);

  const target = init * (targetPct / 100);
  const targetPctDone = !funded && target ? clamp((pnl / target) * 100, 0, 100) : null;

  const reasons = [];
  if (ddBreached) reasons.push("Below dynamic drawdown floor — breached");
  if (!breached && funded && withdrawable <= 0) reasons.push("No profit above initial to withdraw");
  if (!breached && funded && withdrawable > 0 && !payoutMinMet) reasons.push(`Profit must exceed 50% of daily DD (${money(minPayout)})`);
  if (!breached && funded && !consOK) reasons.push(`Best day exceeds ${consPct}% — trim to ${money(maxDay)}`);
  if (!breached && !funded && pnl < target) reasons.push(`${money(target - pnl)} to profit target`);

  const eligible = !breached && funded && withdrawable > 0 && payoutMinMet && consOK;
  let status = funded ? "FUNDED" : "CHALLENGE";
  if (breached) status = "BREACHED";
  else if (eligible) status = "PAYOUT READY";
  else if (!funded && pnl >= target) status = "TARGET MET";

  return { kind: "e8", funded, currentBalance, highestBalance, pnl, pnlPct, floor, locked, cushion, cushionPct, ddBreached,
    dailyLoss, maxLossLimit: trailAmt, minPayout, payoutMinMet, effSplit: split, ddPct, dailyPct, consPct, maxDay, consChecked, consOK, bigDay,
    periodProfit, daysDone, withdrawable, yourShare, target, targetPct: targetPctDone, eligible, status, reasons,
    payoutsTaken: payouts.length };
}

const newE8 = () => ({
  id: crypto.randomUUID(), profileId: "e8-one", nickname: "", phase: "Funded",
  accountSize: 500000, platform: "TradeLocker",
  ddPct: 6, dailyPct: 3, targetPct: 6, split: 100, dayLog: [], payouts: [],
});

// Cumulative realized performance across all accounts, as % of total capital.
// Sums each account's logged daily P&L over the calendar; payouts/withdrawals don't reduce it.
function buildSeries(accounts) {
  const byDate = {};
  let totalCap = 0;
  (accounts || []).forEach((a) => {
    totalCap += a.accountSize || 0;
    (a.dayLog || []).forEach((d) => {
      if (!d.date) return;
      byDate[d.date] = (byDate[d.date] || 0) + (Number(d.amount) || 0);
    });
  });
  const dates = Object.keys(byDate).sort();
  let cum = 0;
  return dates.map((date) => {
    cum += byDate[date];
    return { d: date, p: totalCap ? Math.round((cum / totalCap) * 10000) / 100 : 0 };
  });
}

function analyzeAqua(a, p) {
  const init = a.accountSize;
  const days = (a.dayLog || []).slice();
  const payouts = (a.payouts || []).slice();
  const events = [
    ...days.map((d) => ({ date: d.date, type: "day", amount: d.amount })),
    ...payouts.map((p2) => ({ date: p2.date, type: "payout" })),
  ].sort((x, y) => (x.date < y.date ? -1 : x.date > y.date ? 1 : x.type === "day" ? -1 : 1));

  // Process timeline. A payout withdraws ALL profit and resets balance + trailing peak to initial.
  let bal = init, peak = init;
  const payoutLog = [];
  events.forEach((e) => {
    if (e.type === "day") { bal += e.amount; if (bal > peak) peak = bal; }
    else { payoutLog.push({ date: e.date, amount: Math.max(0, bal - init) }); bal = init; peak = init; }
  });
  const currentBalance = bal;
  const highestBalance = peak;
  const pnl = currentBalance - init;
  const pnlPct = init ? (pnl / init) * 100 : 0;

  // Trailing 6% that never locks — always 6% below the running peak (peak resets on payout)
  const floor = peak - init * (p.maxTrailingPct / 100);
  const cushion = currentBalance - floor;
  const cushionPct = init ? clamp((cushion / init) * 100, 0, 100) : 0;
  const ddBreached = currentBalance <= floor;
  const floatingBreach = !!a.floatingBreach;
  const breached = ddBreached || floatingBreach;

  const dailyLoss = init * (p.dailyLossPct / 100);
  const floatingLimit = init * (p.floatingLimitPct / 100);

  // Current payout period = days after the most recent payout
  const lastPayoutDate = payouts.length ? payouts.map((x) => x.date).sort().slice(-1)[0] : null;
  const periodDays = lastPayoutDate ? days.filter((d) => d.date > lastPayoutDate) : days;

  const qualDayProfit = init * (p.qualifyingDayPct / 100);
  const daysDone = periodDays.filter((d) => d.amount >= qualDayProfit).length;
  const daysMet = daysDone >= p.minTradingDays;

  const periodProfit = periodDays.reduce((s, d) => s + d.amount, 0);
  const bigDay = periodDays.reduce((m, d) => Math.max(m, d.amount), 0);
  const consPct = p.consistencyPct(init);
  const maxDay = periodProfit > 0 ? (periodProfit * consPct) / 100 : 0;
  const consChecked = periodDays.length > 0 && periodProfit > 0;
  const consOK = !consChecked || bigDay <= maxDay;

  // 14-day cycle: 14 days from the first trade of the current period
  const periodDates = periodDays.map((d) => d.date).sort();
  const firstPeriodDate = periodDates.length ? periodDates[0] : null;
  let timeMet = false, eligibleDate = null;
  if (firstPeriodDate) {
    const d0 = new Date(firstPeriodDate + "T00:00:00");
    d0.setDate(d0.getDate() + p.payoutCycleDays);
    eligibleDate = d0.toISOString().slice(0, 10);
    timeMet = todayKey() >= eligibleDate;
  }

  const cap = p.payoutCap(init);
  const taken = payouts.length;
  const cappedLeft = Math.max(0, p.payoutCapCount - taken);
  const activeCap = cap && cappedLeft > 0 ? cap : null;

  const withdrawable = Math.max(0, currentBalance - init);
  const payable = activeCap ? Math.min(withdrawable, activeCap) : withdrawable;
  const yourShare = payable * (p.split / 100);

  const reasons = [];
  if (ddBreached) reasons.push("Below trailing drawdown floor — breached");
  if (floatingBreach) reasons.push("Hit −2% floating loss — account closed");
  if (!breached && withdrawable <= 0) reasons.push("No profit above initial to withdraw");
  if (!breached && withdrawable > 0 && !daysMet) reasons.push(`Need ${p.minTradingDays - daysDone} more qualifying day(s)`);
  if (!breached && !consOK) reasons.push(`Best day exceeds ${consPct}% — trim to ${money(maxDay)}`);
  if (!breached && withdrawable > 0 && daysMet && consOK && !timeMet && eligibleDate) reasons.push(`Payout window opens ${prettyDate(eligibleDate)}`);

  const eligible = !breached && withdrawable > 0 && daysMet && consOK && timeMet;
  let status = "FUNDED";
  if (breached) status = "BREACHED";
  else if (eligible) status = "PAYOUT READY";

  return { kind: "aqua", currentBalance, highestBalance, pnl, pnlPct, floor, locked: false, cushion, cushionPct, ddBreached,
    dailyLoss, maxLossLimit: init * (p.maxTrailingPct / 100), floatingLimit, floatingBreach, effSplit: p.split, qualDayProfit, daysDone, daysMet, minDays: p.minTradingDays,
    consPct, maxDay, consChecked, consOK, bigDay, periodProfit, withdrawable, activeCap, cappedLeft, payoutsTaken: taken,
    eligibleDate, timeMet, yourShare, eligible, status, reasons, payoutLog };
}

const newInstant = () => ({
  id: crypto.randomUUID(), profileId: "bg-instant", nickname: "",
  accountSize: 400000, platform: "TradeLocker",
  guardianBreaches: 0, dayLog: [], payouts: [],
});
const newAqua = () => ({
  id: crypto.randomUUID(), profileId: "aqua-pap", nickname: "",
  accountSize: 250000, platform: "TradeLocker",
  floatingBreach: false, dayLog: [], payouts: [],
});
const newCustom = () => ({
  id: crypto.randomUUID(), profileId: "custom", firm: "", nickname: "", phase: "Funded",
  accountSize: 100000, currentBalance: 100000, profitTarget: 0, dailyLossLimit: 0,
  drawdownFloor: 90000, minTradingDays: 0, tradingDays: 0, profitSplit: 80, payoutThreshold: 0,
});

const STATUS_STYLE = {
  "BREACHED": { c: "var(--red)", bg: "rgba(248,81,73,.12)", Icon: ShieldAlert },
  "PAYOUT READY": { c: "var(--green)", bg: "rgba(63,185,80,.12)", Icon: CheckCircle2 },
  "SHIELD WARNING": { c: "var(--amber)", bg: "rgba(210,153,34,.12)", Icon: AlertTriangle },
  "FUNDED": { c: "var(--cyan)", bg: "rgba(255,255,11,.12)", Icon: ShieldCheck },
  "EVALUATION": { c: "var(--amber)", bg: "rgba(210,153,34,.12)", Icon: Activity },
};

/* ============================ APP ============================ */
export default function PropDesk() {
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [session, setSession] = useState(null);
  const [hidden, setHidden] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [pub, setPub] = useState({ capital: 0, pnl: 0, series: [] });
  const [showLogin, setShowLogin] = useState(false);
  const [adding, setAdding] = useState(false);

  const loadData = async (uid) => {
    if (!sb) return;
    try {
      const { data } = await sb.from("user_data").select("accounts").eq("user_id", uid).maybeSingle();
      setAccounts(data && data.accounts ? data.accounts : []);
    } catch (e) { setAccounts([]); }
  };
  const loadPublic = async () => {
    if (!sb) return;
    try {
      const { data } = await sb.from("public_summary").select("capital,pnl,series").eq("id", 1).maybeSingle();
      if (data) setPub({ capital: Number(data.capital) || 0, pnl: Number(data.pnl) || 0, series: Array.isArray(data.series) ? data.series : [] });
    } catch (e) {}
  };

  useEffect(() => {
    if (!sb) { setLoading(false); return; }
    loadPublic();
    sb.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      if (data.session) await loadData(data.session.user.id);
      setLoading(false);
    });
    const { data: sub } = sb.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      if (s) loadData(s.user.id); else setAccounts([]);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const persist = async (next) => {
    setAccounts(next);
    if (!sb || !session) return;
    setSyncing(true);
    const capital = next.reduce((s, a) => s + a.accountSize, 0);
    const pnl = next.reduce((s, a) => s + analyze(a).pnl, 0);
    const series = buildSeries(next);
    setPub({ capital, pnl, series });
    try {
      await sb.from("user_data").upsert({ user_id: session.user.id, accounts: next, updated_at: new Date().toISOString() });
      await sb.from("public_summary").upsert({ id: 1, capital, pnl, series, updated_at: new Date().toISOString() });
    } catch (e) {}
    setSyncing(false);
  };
  const save = (acc) => {
    const exists = accounts.some((x) => x.id === acc.id);
    persist(exists ? accounts.map((x) => (x.id === acc.id ? acc : x)) : [...accounts, acc]);
    setEditing(null);
  };
  const remove = (id) => persist(accounts.filter((x) => x.id !== id));
  const signOut = async () => { if (sb) await sb.auth.signOut(); setSession(null); setAccounts([]); setHidden(false); };

  const totals = useMemo(() => {
    let capital = 0, pnl = 0, ready = 0, available = 0, breached = 0;
    accounts.forEach((a) => {
      const r = analyze(a);
      capital += a.accountSize; pnl += r.pnl;
      if (r.eligible) { ready++; available += r.yourShare; }
      if (r.status === "BREACHED") breached++;
    });
    return { capital, pnl, ready, available, breached, count: accounts.length };
  }, [accounts]);

  const authed = !!session;

  return (
    <div className="pd-root">
      <style>{CSS}</style>
      <div className="pd-grain" />
      <header className="pd-header">
        <div>
          <div className="pd-brand"><img src={LOGO_SRC} className="pd-logo-img" alt="L24 Global" /> PROP<span className="pd-logo-accent">DESK</span></div>
          <div className="pd-tagline">multi-firm account terminal{syncing ? " · saving…" : ""}</div>
        </div>
        <div className="pd-head-actions">
          {authed ? (
            <>
              {!hidden && <button className="pd-add" onClick={() => setAdding(true)}><Plus size={16} strokeWidth={2.5} /> Add account</button>}
              <button className="pd-ghost" onClick={() => setHidden((h) => !h)} title="Hide details"><Lock size={15} /> {hidden ? "Show" : "Hide"}</button>
              <button className="pd-ghost" onClick={signOut} title="Log out"><X size={15} /> Log out</button>
            </>
          ) : (
            <button className="pd-loginbtn" onClick={() => setShowLogin(true)}><Lock size={14} /> Log in</button>
          )}
        </div>
      </header>

      {authed ? (
        <section className="pd-summary">
          <Stat label="Accounts" value={totals.count} icon={Layers} />
          <Stat label="Capital managed" value={money(totals.capital)} icon={Wallet} />
          <Stat label="Total P&L" value={moneyP(totals.pnl)} icon={totals.pnl >= 0 ? TrendingUp : TrendingDown} color={totals.pnl >= 0 ? "var(--green)" : "var(--red)"} />
          <Stat label="Payouts ready" value={totals.ready} icon={CheckCircle2} color={totals.ready ? "var(--green)" : "var(--dim)"} />
          <Stat label="Available now" value={money(totals.available)} icon={Banknote} color={totals.available ? "var(--green)" : "var(--dim)"} />
          <Stat label="Breached" value={totals.breached} icon={ShieldAlert} color={totals.breached ? "var(--red)" : "var(--dim)"} />
        </section>
      ) : !loading ? (
        <section className="pd-hero">
          <div className="pd-hero-eyebrow"><span className="pd-livedot" /> L24 GLOBAL · LIVE PERFORMANCE</div>
          <div className="pd-hero-grid">
            <div className="pd-hero-stat">
              <div className="pd-hero-label"><Wallet size={14} /> Capital Managed</div>
              <div className="pd-hero-val">{money(pub.capital)}</div>
            </div>
            <div className="pd-hero-divider" />
            <div className="pd-hero-stat">
              <div className="pd-hero-label">{pub.pnl >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />} Total P&L</div>
              <div className="pd-hero-val" style={{ color: pub.pnl >= 0 ? "var(--green)" : "var(--red)" }}>{moneyP(pub.pnl)}</div>
            </div>
          </div>
          <div className="pd-hero-foot">Member access only · <span className="pd-hero-link" onClick={() => setShowLogin(true)}>log in</span></div>
          <PerfChart series={pub.series} />
        </section>
      ) : null}

      {loading ? (
        <div className="pd-empty">Loading your desk…</div>
      ) : !authed ? null : hidden ? (
        <div className="pd-empty">
          <div className="pd-gate-icon" style={{ margin: "0 auto 14px" }}><Lock size={24} /></div>
          <div className="pd-empty-title">Details hidden</div>
          <p>Your metrics stay visible above. Tap “Show” in the header to reveal your accounts again.</p>
        </div>
      ) : accounts.length === 0 ? (
        <div className="pd-empty">
          <div className="pd-empty-title">No accounts yet</div>
          <p>Add a prop-firm account to start tracking. Blue Guardian and AquaFunded have their rules built in — you just enter your live numbers.</p>
          <button className="pd-add" onClick={() => setAdding(true)}><Plus size={16} strokeWidth={2.5} /> Add account</button>
        </div>
      ) : (
        <section className="pd-grid">
          {accounts.map((a) => <Card key={a.id} a={a} onEdit={() => setEditing(a)} onDelete={() => remove(a.id)} />)}
        </section>
      )}

      <footer className="pd-foot">Synced to your account across devices. Firm rules reflect each firm's published terms; always verify against your own dashboard. Not financial advice.</footer>
      {editing && <Editor account={editing} onSave={save} onClose={() => setEditing(null)} />}
      {adding && <AddPicker onPick={(acc) => { setAdding(false); setEditing(acc); }} onClose={() => setAdding(false)} />}
      {showLogin && !authed && <LoginModal onClose={() => setShowLogin(false)} />}
    </div>
  );
}

function Stat({ label, value, icon: Icon, color }) {
  return (
    <div className="pd-stat">
      <div className="pd-stat-top"><span className="pd-stat-label">{label}</span><Icon size={15} style={{ color: color || "var(--dim)" }} /></div>
      <div className="pd-stat-val" style={{ color: color || "var(--ink)" }}>{value}</div>
    </div>
  );
}

function PerfChart({ series }) {
  if (!series || series.length < 2) {
    return <div className="pd-chart-empty"><Activity size={15} /> Performance chart builds as trading days are logged.</div>;
  }
  const W = 720, H = 170, padX = 6, padY = 14;
  const n = series.length;
  const vals = series.map((s) => s.p);
  const min = Math.min(0, ...vals), max = Math.max(0, ...vals);
  const range = (max - min) || 1;
  const X = (i) => padX + (n === 1 ? 0 : (i / (n - 1)) * (W - padX * 2));
  const Y = (v) => padY + (1 - (v - min) / range) * (H - padY * 2);
  const line = series.map((s, i) => `${i === 0 ? "M" : "L"}${X(i).toFixed(1)},${Y(s.p).toFixed(1)}`).join(" ");
  const area = `${line} L${X(n - 1).toFixed(1)},${Y(min).toFixed(1)} L${X(0).toFixed(1)},${Y(min).toFixed(1)} Z`;
  const last = series[n - 1].p;
  const up = last >= 0;
  const col = up ? "var(--green)" : "var(--red)";
  const zeroY = Y(0);
  return (
    <div className="pd-chart">
      <div className="pd-chart-top">
        <span className="pd-chart-label"><Activity size={13} /> Cumulative performance · all-time</span>
        <span className="pd-chart-val" style={{ color: col }}>{up ? "+" : ""}{last.toFixed(2)}%</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="pd-chart-svg">
        <defs>
          <linearGradient id="pdgrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={col} stopOpacity="0.25" />
            <stop offset="100%" stopColor={col} stopOpacity="0" />
          </linearGradient>
        </defs>
        <line x1={padX} y1={zeroY} x2={W - padX} y2={zeroY} stroke="var(--line)" strokeWidth="1" strokeDasharray="4 5" />
        <path d={area} fill="url(#pdgrad)" />
        <path d={line} fill="none" stroke={col} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="pd-chart-axis"><span>{prettyDate(series[0].d)}</span><span>{prettyDate(series[n - 1].d)}</span></div>
    </div>
  );
}

function LoginModal({ onClose }) {
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setErr("");
    if (!sb) { setErr("Cloud not available in preview — open the deployed site."); return; }
    if (!email || !pw) { setErr("Enter your email and password"); return; }
    setBusy(true);
    try {
      const { error } = await sb.auth.signInWithPassword({ email, password: pw });
      if (error) setErr("Incorrect email or password"); else onClose();
    } catch (e) { setErr("Something went wrong. Try again."); }
    setBusy(false);
  };

  return (
    <div className="pd-modal-bg" onClick={onClose}>
      <div className="pd-login" onClick={(e) => e.stopPropagation()}>
        <div className="pd-login-head">
          <span><Lock size={15} /> Log in</span>
          <button onClick={onClose}><X size={18} /></button>
        </div>
        <input className="pd-gate-input" style={{ letterSpacing: 0, textAlign: "left" }} type="email" value={email} autoFocus placeholder="Email"
          onChange={(e) => { setEmail(e.target.value); setErr(""); }} />
        <input className="pd-gate-input" style={{ letterSpacing: 0, textAlign: "left" }} type="password" value={pw} placeholder="Password"
          onChange={(e) => { setPw(e.target.value); setErr(""); }} onKeyDown={(e) => e.key === "Enter" && submit()} />
        {err && <div className="pd-gate-err"><AlertTriangle size={13} /> {err}</div>}
        <button className="pd-add pd-gate-btn" onClick={submit} disabled={busy}>{busy ? "Please wait…" : "Log in"}</button>
        <div className="pd-gate-note">Access is invite-only. Logins are created by an administrator.</div>
      </div>
    </div>
  );
}

function AddPicker({ onPick, onClose }) {
  const firms = [
    { id: "bg-instant", make: newInstant, firm: "Blue Guardian", model: "Instant (Standard)", tag: "TradeLocker · trailing locks at initial" },
    { id: "aqua-pap", make: newAqua, firm: "AquaFunded", model: "Pay-After-Pass (One-Step)", tag: "TradeLocker · trailing resets on payout" },
    { id: "e8-one", make: newE8, firm: "E8 Markets", model: "E8 ONE (1-Step)", tag: "TradeLocker · editable drawdown, trailing locks" },
    { id: "custom", make: newCustom, firm: "Other firm", model: "Enter rules manually", tag: "Any firm — you set the limits" },
  ];
  return (
    <div className="pd-modal-bg" onClick={onClose}>
      <div className="pd-login" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 440 }}>
        <div className="pd-login-head">
          <span><Plus size={16} /> Add account</span>
          <button onClick={onClose}><X size={18} /></button>
        </div>
        <div className="pd-pick-list">
          {firms.map((f) => (
            <button key={f.id} className="pd-pick" onClick={() => onPick(f.make())}>
              <div className="pd-pick-firm">{f.firm}</div>
              <div className="pd-pick-model">{f.model}</div>
              <div className="pd-pick-tag">{f.tag}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function Card({ a, onEdit, onDelete }) {
  const p = PROFILES[a.profileId] || PROFILES.custom;
  const r = analyze(a);
  const s = STATUS_STYLE[r.status] || STATUS_STYLE.FUNDED;
  const isBG = r.kind === "instant";
  const isAqua = r.kind === "aqua";
  const isE8 = r.kind === "e8";
  const isFunded = isBG || isAqua || isE8;
  const [confirmDel, setConfirmDel] = useState(false);

  const maxRoom = Math.max(0, r.cushion || 0);
  const maxUsed = clamp((r.maxLossLimit || 0) - maxRoom, 0, r.maxLossLimit || 0);
  const maxPctUsed = r.maxLossLimit ? clamp((maxUsed / r.maxLossLimit) * 100, 0, 100) : 0;

  return (
    <div className="pd-card" style={r.status === "BREACHED" ? { borderColor: "rgba(248,81,73,.4)" } : {}}>
      <div className="pd-card-head">
        <div>
          <div className="pd-firm">{isFunded ? p.firm : (a.firm || "Unnamed")}</div>
          <div className="pd-label">{a.nickname || (isFunded ? `${p.model} · ${money(a.accountSize)}` : `${a.phase} · ${money(a.accountSize)}`)}</div>
        </div>
        <span className="pd-badge" style={{ color: s.c, background: s.bg }}><s.Icon size={12} strokeWidth={2.5} /> {r.status}</span>
      </div>

      <div className="pd-balance">
        <div>
          <div className="pd-balance-num">{money(isFunded ? r.currentBalance : a.currentBalance)}</div>
          <div className="pd-pnl" style={{ color: r.pnl >= 0 ? "var(--green)" : "var(--red)" }}>{moneyP(r.pnl)} ({r.pnlPct >= 0 ? "+" : ""}{r.pnlPct.toFixed(2)}%)</div>
        </div>
        <div className="pd-phase-tag">{isFunded ? `peak ${money(r.highestBalance)}` : a.phase}</div>
      </div>

      {isFunded ? (
        <>
          <div className="pd-gauges">
            <Gauge label="Max Loss" pct={r.status === "BREACHED" ? 100 : maxPctUsed} usedAmt={maxUsed} totalAmt={r.maxLossLimit} />
          </div>
          <div className="pd-gauge-foot">Floor {money(r.floor)} · {r.locked ? "locked at initial" : "trailing"} · {money(maxRoom)} room left before breach</div>
        </>
      ) : (
        <Bar
          label="Drawdown cushion"
          right={r.status === "BREACHED" ? "BREACHED" : `${money(r.cushion)} to ${money(r.floor)}`}
          pct={r.cushionPct} color={r.cushionPct < 25 ? "var(--red)" : r.cushionPct < 50 ? "var(--amber)" : "var(--green)"} danger={r.cushionPct < 25} />
      )}

      {!isFunded && r.targetPct !== null && (
        <Bar label="Profit target" right={`${money(r.pnl)} / ${money(a.profitTarget)}`} pct={r.targetPct} color="var(--cyan)" />
      )}

      {isBG ? (
        <>
          <div className="pd-rules">
            <Rule icon={AlertTriangle} k="Daily loss" v={money(r.dailyLoss)} sub="resets 5PM EST" />
            <Rule icon={ShieldAlert} k="Shield @1%" v={money(r.shieldTrigger)} sub={`breaches ${r.breaches}/2`} warn={r.breaches >= 1} />
            <Rule icon={CalendarDays} k="Qual. days" v={`${r.daysDone}/${r.minDays}`} sub={`≥${money(r.qualDayProfit)}/day`} warn={!r.daysMet} />
            <Rule icon={Activity} k={`${r.consPct}% rule`} v={r.consChecked ? (r.consOK ? "Pass" : "Blocked") : "—"} sub={`max ${money(r.maxDay)}/day`} warn={r.consChecked && !r.consOK} />
          </div>
          <div className="pd-payout" style={{ borderColor: r.eligible ? "rgba(63,185,80,.3)" : "var(--line)" }}>
            <div>
              <div className="pd-payout-k">Payout · {r.effSplit}% split{r.breaches >= 1 && <span className="pd-thresh"> (reduced)</span>}</div>
              <div className="pd-payout-v" style={{ color: r.eligible ? "var(--green)" : "var(--dim)" }}>
                {r.eligible ? money(r.yourShare) : "—"}
                {r.activeCap && <span className="pd-thresh"> · cap {money(r.activeCap)} ({r.cappedLeft} left)</span>}
              </div>
            </div>
            <span className="pd-payout-status" style={{ color: r.eligible ? "var(--green)" : "var(--dim)", background: r.eligible ? "rgba(63,185,80,.12)" : "transparent" }}>
              {r.eligible ? "ELIGIBLE" : r.status === "BREACHED" ? "LOCKED" : "NOT YET"}
            </span>
          </div>
        </>
      ) : isAqua ? (
        <>
          <div className="pd-rules">
            <Rule icon={AlertTriangle} k="Daily loss" v={money(r.dailyLoss)} sub="resets 00:00 UTC" />
            <Rule icon={ShieldAlert} k="Float −2%" v={money(r.floatingLimit)} sub={r.floatingBreach ? "BREACHED" : "hard limit"} warn={r.floatingBreach} />
            <Rule icon={CalendarDays} k="Qual. days" v={`${r.daysDone}/${r.minDays}`} sub={`≥${money(r.qualDayProfit)}/day`} warn={!r.daysMet} />
            <Rule icon={Activity} k={`${r.consPct}% rule`} v={r.consChecked ? (r.consOK ? "Pass" : "Blocked") : "—"} sub={`max ${money(r.maxDay)}/day`} warn={r.consChecked && !r.consOK} />
          </div>
          <div className="pd-payout" style={{ borderColor: r.eligible ? "rgba(63,185,80,.3)" : "var(--line)" }}>
            <div>
              <div className="pd-payout-k">Payout · {r.effSplit}% split · full profit</div>
              <div className="pd-payout-v" style={{ color: r.eligible ? "var(--green)" : "var(--dim)" }}>
                {r.eligible ? money(r.yourShare) : "—"}
                {r.activeCap && <span className="pd-thresh"> · cap {money(r.activeCap)} ({r.cappedLeft} left)</span>}
              </div>
            </div>
            <span className="pd-payout-status" style={{ color: r.eligible ? "var(--green)" : "var(--dim)", background: r.eligible ? "rgba(63,185,80,.12)" : "transparent" }}>
              {r.eligible ? "ELIGIBLE" : r.status === "BREACHED" ? "LOCKED" : "NOT YET"}
            </span>
          </div>
        </>
      ) : isE8 ? (
        <>
          {!r.funded && r.targetPct !== null && (
            <Bar label="Profit target" right={`${money(r.pnl)} / ${money(r.target)}`} pct={r.targetPct} color="var(--cyan)" />
          )}
          <div className="pd-rules">
            <Rule icon={AlertTriangle} k="Daily loss" v={money(r.dailyLoss)} sub={`${r.dailyPct}% start-of-day`} />
            <Rule icon={ShieldCheck} k="Dynamic DD" v={`${r.ddPct}%`} sub={r.locked ? "locked at initial" : "trailing (closed)"} />
            <Rule icon={Activity} k={`${r.consPct}% best-day`} v={r.consChecked ? (r.consOK ? "Pass" : "Blocked") : "—"} sub={`max ${money(r.maxDay)}/day`} warn={r.consChecked && !r.consOK} />
            <Rule icon={Banknote} k="Min payout" v={money(r.minPayout)} sub={r.funded ? (r.payoutMinMet ? "met" : "50% daily DD") : "when funded"} warn={r.funded && r.withdrawable > 0 && !r.payoutMinMet} />
          </div>
          <div className="pd-payout" style={{ borderColor: r.eligible ? "rgba(63,185,80,.3)" : "var(--line)" }}>
            <div>
              <div className="pd-payout-k">Payout · {r.effSplit}% split</div>
              <div className="pd-payout-v" style={{ color: r.eligible ? "var(--green)" : "var(--dim)" }}>
                {r.eligible ? money(r.yourShare) : "—"}
                <span className="pd-thresh"> · leave a buffer</span>
              </div>
            </div>
            <span className="pd-payout-status" style={{ color: r.eligible ? "var(--green)" : "var(--dim)", background: r.eligible ? "rgba(63,185,80,.12)" : "transparent" }}>
              {r.eligible ? "ELIGIBLE" : r.status === "BREACHED" ? "LOCKED" : r.funded ? "NOT YET" : "CHALLENGE"}
            </span>
          </div>
        </>
      ) : (
        <div className="pd-payout" style={{ borderColor: r.eligible ? "rgba(63,185,80,.3)" : "var(--line)" }}>
          <div>
            <div className="pd-payout-k">Payout · {a.profitSplit}% split</div>
            <div className="pd-payout-v" style={{ color: r.eligible ? "var(--green)" : "var(--dim)" }}>{r.yourShare > 0 ? money(r.yourShare) : "—"}</div>
          </div>
          <span className="pd-payout-status" style={{ color: r.eligible ? "var(--green)" : "var(--dim)", background: r.eligible ? "rgba(63,185,80,.12)" : "transparent" }}>
            {r.eligible ? "ELIGIBLE" : r.status === "BREACHED" ? "LOCKED" : r.isFunded ? "NOT YET" : "IN EVAL"}
          </span>
        </div>
      )}

      {r.reasons.length > 0 && !r.eligible && (
        <div className="pd-reasons">{r.reasons.map((t, i) => <div key={i} className="pd-reason"><XCircle size={12} /> {t}</div>)}</div>
      )}

      {confirmDel ? (
        <div className="pd-actions pd-confirm-del">
          <span className="pd-confirm-txt"><AlertTriangle size={13} /> Delete this account?</span>
          <button className="pd-del-yes" onClick={onDelete}>Yes, delete</button>
          <button onClick={() => setConfirmDel(false)}>Cancel</button>
        </div>
      ) : (
        <div className="pd-actions">
          <button onClick={onEdit}><Pencil size={14} /> Update numbers</button>
          <button onClick={() => setConfirmDel(true)} className="pd-del"><Trash2 size={14} /></button>
        </div>
      )}
    </div>
  );
}

function Gauge({ label, pct, usedAmt, totalAmt }) {
  const R = 54, C = 2 * Math.PI * R;
  const p = clamp(pct, 0, 100);
  const off = C * (1 - p / 100);
  const col = p >= 80 ? "var(--red)" : p >= 50 ? "var(--amber)" : "var(--green)";
  return (
    <div className="pd-gauge">
      <div className="pd-gauge-label">{label}</div>
      <div className="pd-gauge-ring">
        <svg viewBox="0 0 130 130">
          <circle cx="65" cy="65" r={R} fill="none" stroke="var(--line)" strokeWidth="9" />
          <circle cx="65" cy="65" r={R} fill="none" stroke={col} strokeWidth="9" strokeLinecap="round"
            strokeDasharray={C.toFixed(1)} strokeDashoffset={off.toFixed(1)} transform="rotate(-90 65 65)" />
        </svg>
        <div className="pd-gauge-pct" style={{ color: col }}>{Math.round(p)}%</div>
      </div>
      <div className="pd-gauge-amt"><b>{money(usedAmt)}</b> / {money(totalAmt)}</div>
    </div>
  );
}

function Bar({ label, right, pct, color, danger }) {
  return (
    <div className="pd-bar-wrap">
      <div className="pd-bar-top"><span>{label}</span><span style={{ color: danger ? "var(--red)" : "var(--mid)" }}>{right}</span></div>
      <div className="pd-bar-track"><div className="pd-bar-fill" style={{ width: `${pct}%`, background: color }} /></div>
    </div>
  );
}

function Rule({ icon: Icon, k, v, sub, warn }) {
  return (
    <div className="pd-rule">
      <Icon size={13} style={{ color: warn ? "var(--amber)" : "var(--dim)", marginTop: 2 }} />
      <div>
        <div className="pd-rule-k">{k}</div>
        <div className="pd-rule-v" style={warn ? { color: "var(--amber)" } : {}}>{v}</div>
        {sub && <div className="pd-rule-sub">{sub}</div>}
      </div>
    </div>
  );
}

/* ============================ EDITOR ============================ */
function Editor({ account, onSave, onClose }) {
  const [f, setF] = useState(account);
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const num = (k, v) => set(k, v === "" ? 0 : Number(v));
  const isBG = f.profileId === "bg-instant";
  const isAqua = f.profileId === "aqua-pap";
  const isE8 = f.profileId === "e8-one";
  const p = PROFILES[f.profileId];

  return (
    <div className="pd-modal-bg" onClick={onClose}>
      <div className="pd-modal" onClick={(e) => e.stopPropagation()}>
        <div className="pd-modal-head">
          <span>{isBG ? "Blue Guardian · Instant" : isAqua ? "AquaFunded · Pay-After-Pass" : isE8 ? "E8 Markets · E8 ONE" : (account.firm ? "Edit account" : "New account")}</span>
          <button onClick={onClose}><X size={18} /></button>
        </div>

        {isBG ? (
          <>
            <div className="pd-form">
              <Field label="Nickname" full><input value={f.nickname} onChange={(e) => set("nickname", e.target.value)} placeholder="My 400K Instant" /></Field>
              <Field label="Account size">
                <select value={f.accountSize} onChange={(e) => num("accountSize", e.target.value)}>{SIZES.map((s) => <option key={s} value={s}>{money(s)}</option>)}</select>
              </Field>
              <Field label="Platform">
                <select value={f.platform} onChange={(e) => set("platform", e.target.value)}>{["TradeLocker", "MatchTrader", "MetaTrader 5"].map((x) => <option key={x}>{x}</option>)}</select>
              </Field>
              <Field label="Guardian Shield breaches">
                <select value={f.guardianBreaches} onChange={(e) => num("guardianBreaches", e.target.value)}>
                  <option value={0}>0 — clean</option><option value={1}>1 — split cut to 50%</option><option value={2}>2 — terminated</option>
                </select>
              </Field>
            </div>

            <LiveSummary f={f} />
            <DailyLog f={f} setF={setF} />
            <Payouts f={f} setF={setF} />

            <div className="pd-ruleset">
              <div className="pd-ruleset-h"><Info size={13} /> Built-in rules for this model</div>
              {p.notes.map((n, i) => <div key={i} className="pd-ruleset-item">{n}</div>)}
            </div>
          </>
        ) : isAqua ? (
          <>
            <div className="pd-form">
              <Field label="Nickname" full><input value={f.nickname} onChange={(e) => set("nickname", e.target.value)} placeholder="My 250K Pay-After-Pass" /></Field>
              <Field label="Account size">
                <select value={f.accountSize} onChange={(e) => num("accountSize", e.target.value)}>{SIZES.map((s) => <option key={s} value={s}>{money(s)}</option>)}</select>
              </Field>
              <Field label="Platform">
                <select value={f.platform} onChange={(e) => set("platform", e.target.value)}>{["TradeLocker", "MatchTrader", "MetaTrader 5", "cTrader"].map((x) => <option key={x}>{x}</option>)}</select>
              </Field>
              <Field label="Account status">
                <select value={f.floatingBreach ? 1 : 0} onChange={(e) => set("floatingBreach", e.target.value === "1")}>
                  <option value={0}>Active</option><option value={1}>−2% floating breach (closed)</option>
                </select>
              </Field>
            </div>

            <LiveSummary f={f} />
            <DailyLog f={f} setF={setF} />
            <AquaPayouts f={f} setF={setF} />

            <div className="pd-ruleset">
              <div className="pd-ruleset-h"><Info size={13} /> Built-in rules for this model</div>
              {p.notes.map((n, i) => <div key={i} className="pd-ruleset-item">{n}</div>)}
            </div>
          </>
        ) : isE8 ? (
          <>
            <div className="pd-form">
              <Field label="Nickname" full><input value={f.nickname} onChange={(e) => set("nickname", e.target.value)} placeholder="My E8 ONE 500K" /></Field>
              <Field label="Account size ($)"><input type="number" value={f.accountSize} onChange={(e) => num("accountSize", e.target.value)} /></Field>
              <Field label="Platform"><select value={f.platform} onChange={(e) => set("platform", e.target.value)}>{["TradeLocker", "MetaTrader 5", "cTrader"].map((x) => <option key={x}>{x}</option>)}</select></Field>
              <Field label="Phase"><select value={f.phase} onChange={(e) => set("phase", e.target.value)}>{["Funded", "Challenge"].map((x) => <option key={x}>{x}</option>)}</select></Field>
              <Field label="Dynamic DD (%)" hint="trailing, locks at initial"><input type="number" step="0.1" value={f.ddPct} onChange={(e) => num("ddPct", e.target.value)} /></Field>
              <Field label="Daily DD (%)"><input type="number" step="0.1" value={f.dailyPct} onChange={(e) => num("dailyPct", e.target.value)} /></Field>
              <Field label="Profit target (%)" hint="challenge only"><input type="number" step="0.1" value={f.targetPct} onChange={(e) => num("targetPct", e.target.value)} /></Field>
              <Field label="Profit split (%)"><input type="number" value={f.split} onChange={(e) => num("split", e.target.value)} /></Field>
            </div>

            <LiveSummary f={f} />
            <DailyLog f={f} setF={setF} />
            <E8Payouts f={f} setF={setF} />

            <div className="pd-ruleset">
              <div className="pd-ruleset-h"><Info size={13} /> Built-in rules for this model</div>
              {p.notes.map((n, i) => <div key={i} className="pd-ruleset-item">{n}</div>)}
            </div>
          </>
        ) : (
          <div className="pd-form">
            <Field label="Prop firm" full><input value={f.firm} onChange={(e) => set("firm", e.target.value)} placeholder="FTMO, Topstep…" /></Field>
            <Field label="Nickname" full><input value={f.nickname} onChange={(e) => set("nickname", e.target.value)} placeholder="Swing 100K" /></Field>
            <Field label="Phase"><select value={f.phase} onChange={(e) => set("phase", e.target.value)}>{["Challenge", "Verification", "Funded"].map((x) => <option key={x}>{x}</option>)}</select></Field>
            <Field label="Account size ($)"><input type="number" value={f.accountSize} onChange={(e) => num("accountSize", e.target.value)} /></Field>
            <Field label="Current balance ($)"><input type="number" value={f.currentBalance} onChange={(e) => num("currentBalance", e.target.value)} /></Field>
            <Field label="Drawdown floor ($)" hint="breach level"><input type="number" value={f.drawdownFloor} onChange={(e) => num("drawdownFloor", e.target.value)} /></Field>
            <Field label="Profit target ($)" hint="0 if none"><input type="number" value={f.profitTarget} onChange={(e) => num("profitTarget", e.target.value)} /></Field>
            <Field label="Daily loss limit ($)"><input type="number" value={f.dailyLossLimit} onChange={(e) => num("dailyLossLimit", e.target.value)} /></Field>
            <Field label="Min trading days"><input type="number" value={f.minTradingDays} onChange={(e) => num("minTradingDays", e.target.value)} /></Field>
            <Field label="Days completed"><input type="number" value={f.tradingDays} onChange={(e) => num("tradingDays", e.target.value)} /></Field>
            <Field label="Profit split (%)"><input type="number" value={f.profitSplit} onChange={(e) => num("profitSplit", e.target.value)} /></Field>
            <Field label="Min profit for payout ($)"><input type="number" value={f.payoutThreshold} onChange={(e) => num("payoutThreshold", e.target.value)} /></Field>
          </div>
        )}

        <div className="pd-modal-foot">
          <button className="pd-ghost" onClick={onClose}>Cancel</button>
          <button className="pd-add" onClick={() => onSave(f)} disabled={!isBG && !isAqua && !isE8 && !f.firm.trim()}>Save account</button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, hint, full, children }) {
  return (
    <label className={"pd-field" + (full ? " pd-field-full" : "")}>
      <span className="pd-field-label">{label}{hint && <em>{hint}</em>}</span>
      {children}
    </label>
  );
}

const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const MON3 = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const DOW = ["S","M","T","W","T","F","S"];
const pad2 = (n) => String(n).padStart(2, "0");
const dateKeyOf = (y, m, d) => `${y}-${pad2(m + 1)}-${pad2(d)}`;
const todayKey = () => { const d = new Date(); return dateKeyOf(d.getFullYear(), d.getMonth(), d.getDate()); };
const prettyDate = (k) => { const [y, m, d] = k.split("-").map(Number); return `${MON3[m - 1]} ${d}, ${y}`; };
const compact = (n) => {
  const a = Math.abs(n), s = n < 0 ? "-" : "+";
  if (a >= 1000) return s + (a / 1000).toFixed(a % 1000 === 0 ? 0 : 1).replace(/\.0$/, "") + "k";
  return s + a;
};

function DailyLog({ f, setF }) {
  const threshold = f.accountSize * 0.005;
  const log = f.dayLog || [];
  const byDate = {};
  log.forEach((d) => { if (d.date) byDate[d.date] = d; });

  const now = new Date();
  const [view, setView] = useState({ y: now.getFullYear(), m: now.getMonth() });
  const [sel, setSel] = useState(todayKey());
  const [val, setVal] = useState(byDate[todayKey()] ? String(byDate[todayKey()].amount) : "");
  const [confirming, setConfirming] = useState(false);

  const resetPeriod = () => {
    setF((p) => ({ ...p, dayLog: [], payouts: [] }));
    setVal("");
    setConfirming(false);
  };

  const setDay = (key, amount) => {
    setF((p) => {
      const list = (p.dayLog || []).filter((d) => d.date !== key);
      if (amount === null || amount === "" || isNaN(Number(amount)))
        return { ...p, dayLog: list };
      return { ...p, dayLog: [...list, { id: crypto.randomUUID(), date: key, amount: Number(amount) }] };
    });
  };

  const lastPayoutDate = (f.payouts || []).length ? (f.payouts || []).map((x) => x.date).sort().slice(-1)[0] : null;
  const inPeriod = (key) => !lastPayoutDate || key > lastPayoutDate;
  const periodDays = log.filter((d) => inPeriod(d.date));
  const qualCount = periodDays.filter((d) => d.amount >= threshold).length;
  const total = periodDays.reduce((s, d) => s + d.amount, 0);

  const firstDow = new Date(view.y, view.m, 1).getDay();
  const daysInMonth = new Date(view.y, view.m + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < firstDow; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const prev = () => setView((v) => (v.m === 0 ? { y: v.y - 1, m: 11 } : { y: v.y, m: v.m - 1 }));
  const next = () => setView((v) => (v.m === 11 ? { y: v.y + 1, m: 0 } : { y: v.y, m: v.m + 1 }));

  const tKey = todayKey();
  const selectDay = (key) => { setSel(key); setVal(byDate[key] ? String(byDate[key].amount) : ""); };
  const save = () => { if (sel) setDay(sel, val === "" ? null : val); };
  const clear = () => { if (sel) { setDay(sel, null); setVal(""); } };

  return (
    <div className="pd-log">
      <div className="pd-log-head">
        <div className="pd-log-title"><CalendarDays size={13} /> Profit calendar · this period</div>
        <div className="pd-log-meta">
          <span className={qualCount >= 5 ? "pd-ok" : "pd-warn"}>{qualCount}/5 qualifying</span>
          <span style={{ color: total >= 0 ? "var(--green)" : "var(--red)" }}>{moneyP(total)}</span>
        </div>
      </div>

      <div className="pd-cal-nav">
        <button type="button" onClick={prev}>‹</button>
        <span>{MONTHS[view.m]} {view.y}</span>
        <button type="button" onClick={next}>›</button>
      </div>

      <div className="pd-cal-grid">
        {DOW.map((d, i) => <div key={"h" + i} className="pd-cal-dow">{d}</div>)}
        {cells.map((d, i) => {
          if (d === null) return <div key={"e" + i} className="pd-cal-empty" />;
          const key = dateKeyOf(view.y, view.m, d);
          const e = byDate[key];
          const period = inPeriod(key);
          const q = e && e.amount >= threshold && period;
          const future = key > tKey;
          let cls = "pd-cal-cell";
          if (key === sel) cls += " sel";
          if (key === tKey) cls += " today";
          if (future) cls += " future";
          if (!period) cls += " past";
          if (e) cls += e.amount >= 0 ? " pos" : " neg";
          return (
            <button type="button" key={key} className={cls} disabled={future} onClick={() => selectDay(key)}>
              <span className="pd-cal-num">{d}</span>
              {e && <span className="pd-cal-amt" style={{ color: e.amount >= 0 ? "var(--green)" : "var(--red)" }}>{compact(e.amount)}</span>}
              {q && <span className="pd-cal-dot" />}
            </button>
          );
        })}
      </div>

      {sel && (
        <div className="pd-cal-editor">
          <div className="pd-cal-editor-date">{prettyDate(sel)}{sel === tKey && " · today"}</div>
          <div className="pd-log-add">
            <input type="number" value={val} placeholder={`Profit (qualifies ≥ ${money(threshold)})`}
              onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), save())} />
            <button type="button" onClick={save}>Save</button>
            {byDate[sel] && <button type="button" className="pd-cal-clear" onClick={clear}><Trash2 size={14} /></button>}
          </div>
        </div>
      )}

      <div className="pd-log-note">Tap any date to log or edit that day's profit — backfill freely, in any order. Balance and peak update automatically. Days ≥0.5% in the current period get a green dot and count toward the 5; the biggest feeds the consistency check. Recording a payout below starts a fresh period (earlier days dim out).</div>

      <div className="pd-reset-row">
        {confirming ? (
          <>
            <span className="pd-reset-q">Wipe all days and payouts?</span>
            <button type="button" className="pd-reset-yes" onClick={resetPeriod}>Yes, clear all</button>
            <button type="button" className="pd-reset-no" onClick={() => setConfirming(false)}>Cancel</button>
          </>
        ) : (
          <button type="button" className="pd-reset-btn" disabled={log.length === 0 && (f.payouts || []).length === 0} onClick={() => setConfirming(true)}>
            <Trash2 size={13} /> Clear all history
          </button>
        )}
      </div>
    </div>
  );
}


function LiveSummary({ f }) {
  const r = analyze(f);
  return (
    <div className="pd-live">
      <LiveCell label="Current balance" value={money(r.currentBalance)} />
      <LiveCell label="Peak (watermark)" value={money(r.highestBalance)} sub={r.locked ? "floor locked" : "trailing"} />
      <LiveCell label="Drawdown floor" value={money(r.floor)} sub={`${money(r.cushion)} cushion`} danger={r.cushionPct < 25} />
      <LiveCell label="Withdrawable now" value={money(r.withdrawable)} sub={`your ${r.effSplit}% = ${money(r.yourShare)}`} good={r.eligible} />
    </div>
  );
}
function LiveCell({ label, value, sub, good, danger }) {
  return (
    <div className="pd-live-cell">
      <div className="pd-live-label">{label}</div>
      <div className="pd-live-val" style={{ color: danger ? "var(--red)" : good ? "var(--green)" : "var(--ink)" }}>{value}</div>
      {sub && <div className="pd-live-sub">{sub}</div>}
    </div>
  );
}

function Payouts({ f, setF }) {
  const list = (f.payouts || []).slice().sort((a, b) => (a.date < b.date ? 1 : -1));
  const [date, setDate] = useState(todayKey());
  const [amt, setAmt] = useState("");
  const [confirm, setConfirm] = useState(false);
  const cap = PROFILES["bg-instant"].payoutCap(f.accountSize);
  const capCount = PROFILES["bg-instant"].payoutCapCount;
  const taken = (f.payouts || []).length;
  const split = (f.guardianBreaches || 0) >= 1 ? 50 : 80;
  const amount = Number(amt);
  const valid = amt !== "" && !isNaN(amount) && amount > 0;

  const ask = () => { if (valid) setConfirm(true); };
  const add = () => {
    if (!valid) return;
    setF((p) => ({ ...p, payouts: [...(p.payouts || []), { id: crypto.randomUUID(), date, amount }] }));
    setAmt(""); setConfirm(false);
  };
  const remove = (id) => setF((p) => ({ ...p, payouts: (p.payouts || []).filter((x) => x.id !== id) }));

  return (
    <div className="pd-log">
      <div className="pd-log-head">
        <div className="pd-log-title"><Banknote size={13} /> Payouts</div>
        <div className="pd-log-meta">
          <span className="pd-warn">{taken} taken</span>
          {cap && taken < capCount && <span style={{ color: "var(--dim)" }}>cap {money(cap)} · {capCount - taken} left</span>}
        </div>
      </div>
      <div className="pd-pay-add">
        <input type="date" value={date} max={todayKey()} onChange={(e) => { setDate(e.target.value); setConfirm(false); }} />
        <input type="number" value={amt} placeholder="Amount withdrawn ($)" onChange={(e) => { setAmt(e.target.value); setConfirm(false); }}
          onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), ask())} />
        <button type="button" onClick={ask} disabled={!valid}><Plus size={15} /> Record</button>
      </div>
      {confirm && (
        <div className="pd-pay-confirm">
          <span><AlertTriangle size={13} /> Record a {money(amount)} payout on {prettyDate(date)}? This lowers your balance and starts a new period.</span>
          <div className="pd-pay-confirm-btns">
            <button type="button" className="pd-pay-yes" onClick={add}>Confirm payout</button>
            <button type="button" className="pd-pay-no" onClick={() => setConfirm(false)}>Cancel</button>
          </div>
        </div>
      )}
      {list.length > 0 && (
        <div className="pd-log-list">
          {list.map((pp) => (
            <div key={pp.id} className="pd-log-row">
              <span className="pd-log-day" style={{ width: "auto" }}>{prettyDate(pp.date)}</span>
              <span className="pd-log-amt" style={{ color: "var(--red)" }}>−{money(pp.amount)}</span>
              <span className="pd-log-tag" style={{ color: "var(--green)", borderColor: "rgba(63,185,80,.3)" }}>you {money(pp.amount * split / 100)}</span>
              <button type="button" onClick={() => remove(pp.id)}><X size={13} /></button>
            </div>
          ))}
        </div>
      )}
      <div className="pd-log-note">Record the amount withdrawn from the account — it lowers your balance and starts a new payout period. The first {capCount} payouts are capped at {cap ? money(cap) : "—"} each; your {split}% share is shown per payout.</div>
    </div>
  );
}

function AquaPayouts({ f, setF }) {
  const r = analyze(f);
  const init = f.accountSize;
  const log = (r.payoutLog || []).slice().sort((a, b) => (a.date < b.date ? 1 : -1));
  const [date, setDate] = useState(todayKey());
  const [confirm, setConfirm] = useState(false);
  const profitNow = Math.max(0, r.currentBalance - init);

  const add = () => {
    setF((p) => ({ ...p, payouts: [...(p.payouts || []), { id: crypto.randomUUID(), date }] }));
    setConfirm(false);
  };
  const remove = (d) => setF((p) => ({ ...p, payouts: (p.payouts || []).filter((x) => x.date !== d) }));

  return (
    <div className="pd-log">
      <div className="pd-log-head">
        <div className="pd-log-title"><Banknote size={13} /> Payouts</div>
        <div className="pd-log-meta">
          <span className="pd-warn">{log.length} taken</span>
          {r.activeCap && <span style={{ color: "var(--dim)" }}>cap {money(r.activeCap)} · {r.cappedLeft} left</span>}
        </div>
      </div>
      <div className="pd-pay-add">
        <input type="date" value={date} max={todayKey()} onChange={(e) => { setDate(e.target.value); setConfirm(false); }} />
        <button type="button" onClick={() => setConfirm(true)} disabled={profitNow <= 0}><Plus size={15} /> Record payout</button>
      </div>
      {confirm && (
        <div className="pd-pay-confirm">
          <span><AlertTriangle size={13} /> Record a payout on {prettyDate(date)}? This withdraws your entire profit ({money(profitNow)}) and resets your balance and trailing drawdown to {money(init)}.</span>
          <div className="pd-pay-confirm-btns">
            <button type="button" className="pd-pay-yes" onClick={add}>Confirm payout</button>
            <button type="button" className="pd-pay-no" onClick={() => setConfirm(false)}>Cancel</button>
          </div>
        </div>
      )}
      {log.length > 0 && (
        <div className="pd-log-list">
          {log.map((x) => (
            <div key={x.date} className="pd-log-row">
              <span className="pd-log-day" style={{ width: "auto" }}>{prettyDate(x.date)}</span>
              <span className="pd-log-amt" style={{ color: "var(--green)" }}>{money(x.amount)}</span>
              <span className="pd-log-tag" style={{ color: "var(--dim)", borderColor: "var(--line)" }}>reset to {money(init)}</span>
              <button type="button" onClick={() => remove(x.date)}><X size={13} /></button>
            </div>
          ))}
        </div>
      )}
      <div className="pd-log-note">A payout withdraws your entire profit and resets both balance and the trailing drawdown to {money(init)}. The first 2 payouts are capped at {money(10000)} each. Days before a payout dim out and a fresh 14-day period begins.</div>
    </div>
  );
}

function E8Payouts({ f, setF }) {
  const list = (f.payouts || []).slice().sort((a, b) => (a.date < b.date ? 1 : -1));
  const split = f.split != null ? f.split : 100;
  const [date, setDate] = useState(todayKey());
  const [amt, setAmt] = useState("");
  const [confirm, setConfirm] = useState(false);
  const amount = Number(amt);
  const valid = amt !== "" && !isNaN(amount) && amount > 0;

  const ask = () => { if (valid) setConfirm(true); };
  const add = () => {
    if (!valid) return;
    setF((p) => ({ ...p, payouts: [...(p.payouts || []), { id: crypto.randomUUID(), date, amount }] }));
    setAmt(""); setConfirm(false);
  };
  const remove = (id) => setF((p) => ({ ...p, payouts: (p.payouts || []).filter((x) => x.id !== id) }));

  return (
    <div className="pd-log">
      <div className="pd-log-head">
        <div className="pd-log-title"><Banknote size={13} /> Payouts</div>
        <div className="pd-log-meta"><span className="pd-warn">{list.length} taken</span></div>
      </div>
      <div className="pd-pay-add">
        <input type="date" value={date} max={todayKey()} onChange={(e) => { setDate(e.target.value); setConfirm(false); }} />
        <input type="number" value={amt} placeholder="Amount withdrawn ($)" onChange={(e) => { setAmt(e.target.value); setConfirm(false); }}
          onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), ask())} />
        <button type="button" onClick={ask} disabled={!valid}><Plus size={15} /> Record</button>
      </div>
      {confirm && (
        <div className="pd-pay-confirm">
          <span><AlertTriangle size={13} /> Record a {money(amount)} payout on {prettyDate(date)}? This lowers your balance. Remember to leave a buffer — withdrawing all profit closes an E8 account.</span>
          <div className="pd-pay-confirm-btns">
            <button type="button" className="pd-pay-yes" onClick={add}>Confirm payout</button>
            <button type="button" className="pd-pay-no" onClick={() => setConfirm(false)}>Cancel</button>
          </div>
        </div>
      )}
      {list.length > 0 && (
        <div className="pd-log-list">
          {list.map((pp) => (
            <div key={pp.id} className="pd-log-row">
              <span className="pd-log-day" style={{ width: "auto" }}>{prettyDate(pp.date)}</span>
              <span className="pd-log-amt" style={{ color: "var(--red)" }}>−{money(pp.amount)}</span>
              <span className="pd-log-tag" style={{ color: "var(--green)", borderColor: "rgba(63,185,80,.3)" }}>you {money(pp.amount * split / 100)}</span>
              <button type="button" onClick={() => remove(pp.id)}><X size={13} /></button>
            </div>
          ))}
        </div>
      )}
      <div className="pd-log-note">E8 payouts are on-demand and don't reset the account — they lower your balance. Don't withdraw your entire profit or the account closes; leave a drawdown buffer.</div>
    </div>
  );
}

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap');
.pd-root{--bg:#080b10;--panel:#0e131b;--panel2:#121925;--line:#1d2735;--ink:#e8eef6;--mid:#9fb0c4;--dim:#5d6c80;--green:#3fb950;--red:#f85149;--amber:#d29922;--cyan:#FFFF0B;
  font-family:'IBM Plex Sans',sans-serif;background:var(--bg);color:var(--ink);min-height:100vh;padding:22px clamp(14px,4vw,40px) 60px;position:relative;overflow-x:hidden;}
.pd-root *{box-sizing:border-box;}
.pd-grain{position:fixed;inset:0;pointer-events:none;opacity:.04;z-index:0;background-image:radial-gradient(var(--ink) 1px,transparent 0);background-size:3px 3px;}
.pd-root>*{position:relative;z-index:1;}
.pd-header{display:flex;justify-content:space-between;align-items:flex-end;flex-wrap:wrap;gap:14px;margin-bottom:24px;border-bottom:1px solid var(--line);padding-bottom:18px;}
.pd-brand{font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:clamp(26px,5vw,38px);letter-spacing:-1px;line-height:1;}
.pd-logo-accent{color:var(--cyan);}
.pd-logo-img{height:32px;width:auto;vertical-align:-7px;margin-right:8px;border-radius:3px;}
.pd-tagline{color:var(--dim);font-family:'IBM Plex Mono',monospace;font-size:11px;text-transform:uppercase;letter-spacing:2px;margin-top:7px;}
.pd-head-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center;}
.pd-locktag{display:inline-flex;align-items:center;gap:6px;font-family:'IBM Plex Mono';font-size:11px;text-transform:uppercase;letter-spacing:1px;color:var(--dim);border:1px solid var(--line);padding:7px 12px;border-radius:9px;}
.pd-gate{display:flex;justify-content:center;padding:30px 10px 50px;}
.pd-gate-card{width:100%;max-width:380px;background:linear-gradient(160deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:18px;padding:30px 26px;text-align:center;animation:rise .35s ease both;}
.pd-gate-icon{width:54px;height:54px;margin:0 auto 16px;border-radius:14px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,11,.1);border:1px solid rgba(255,255,11,.3);color:var(--cyan);}
.pd-gate-title{font-family:'Bricolage Grotesque';font-weight:800;font-size:21px;letter-spacing:-.4px;}
.pd-gate-sub{color:var(--mid);font-size:13px;line-height:1.5;margin:8px 0 20px;}
.pd-gate-input{width:100%;background:#0a0f16;border:1px solid var(--line);color:var(--ink);font-family:'IBM Plex Mono';font-size:15px;padding:12px 14px;border-radius:10px;outline:none;margin-bottom:10px;text-align:center;letter-spacing:2px;transition:.15s;}
.pd-gate-input:focus{border-color:var(--cyan);}
.pd-gate-err{display:flex;align-items:center;justify-content:center;gap:6px;color:var(--red);font-family:'IBM Plex Mono';font-size:12px;margin-bottom:10px;}
.pd-gate-btn{width:100%;justify-content:center;margin-top:4px;}
.pd-gate-note{color:var(--dim);font-size:10.5px;font-family:'IBM Plex Mono';line-height:1.5;margin-top:14px;}
.pd-gate-msg{display:flex;align-items:center;justify-content:center;gap:6px;color:var(--green);font-family:'IBM Plex Mono';font-size:11.5px;margin-bottom:10px;line-height:1.4;}
.pd-gate-switch{margin-top:14px;color:var(--cyan);font-size:12.5px;cursor:pointer;font-family:'IBM Plex Sans';}
.pd-gate-switch:hover{text-decoration:underline;}
.pd-pick-list{display:flex;flex-direction:column;gap:10px;}
.pd-pick{text-align:left;background:#0a0f16;border:1px solid var(--line);border-radius:12px;padding:14px 16px;cursor:pointer;transition:.15s;color:var(--ink);}
.pd-pick:hover{border-color:var(--cyan);transform:translateY(-1px);}
.pd-pick-firm{font-family:'Bricolage Grotesque';font-weight:800;font-size:16px;}
.pd-pick-model{font-size:13px;color:var(--mid);margin-top:2px;}
.pd-pick-tag{font-family:'IBM Plex Mono';font-size:10.5px;color:var(--dim);margin-top:6px;text-transform:uppercase;letter-spacing:.5px;}
.pd-add{display:inline-flex;align-items:center;gap:7px;background:var(--cyan);color:#161600;border:none;font-weight:600;font-family:'IBM Plex Sans';font-size:14px;padding:10px 16px;border-radius:9px;cursor:pointer;transition:.15s;}
.pd-add:hover{filter:brightness(1.1);transform:translateY(-1px);}.pd-add:disabled{opacity:.4;cursor:not-allowed;transform:none;}
.pd-ghost{background:transparent;color:var(--mid);border:1px solid var(--line);font-family:'IBM Plex Sans';font-size:14px;padding:10px 16px;border-radius:9px;cursor:pointer;transition:.15s;display:inline-flex;align-items:center;gap:6px;}
.pd-ghost:hover{border-color:var(--dim);color:var(--ink);}
.pd-summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:26px;}
.pd-public{display:none;}
.pd-loginbtn{display:inline-flex;align-items:center;gap:7px;background:var(--cyan);color:#161600;border:none;font-weight:600;font-family:'IBM Plex Sans';font-size:13px;padding:9px 16px;border-radius:9px;cursor:pointer;transition:.15s;}
.pd-loginbtn:hover{filter:brightness(1.1);transform:translateY(-1px);}
.pd-hero{margin:30px 0 40px;padding:40px 28px;background:linear-gradient(160deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:20px;text-align:center;position:relative;overflow:hidden;}
.pd-hero:before{content:"";position:absolute;top:-40%;left:50%;transform:translateX(-50%);width:120%;height:80%;background:radial-gradient(ellipse at center, rgba(255,255,11,.06), transparent 70%);pointer-events:none;}
.pd-hero-eyebrow{display:inline-flex;align-items:center;gap:8px;font-family:'IBM Plex Mono';font-size:11px;letter-spacing:3px;color:var(--mid);margin-bottom:28px;}
.pd-livedot{width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 0 0 rgba(63,185,80,.5);animation:pulse 2s infinite;}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(63,185,80,.5);}70%{box-shadow:0 0 0 8px rgba(63,185,80,0);}100%{box-shadow:0 0 0 0 rgba(63,185,80,0);}}
.pd-hero-grid{display:flex;align-items:center;justify-content:center;gap:clamp(20px,6vw,70px);flex-wrap:wrap;position:relative;}
.pd-hero-stat{display:flex;flex-direction:column;align-items:center;gap:10px;}
.pd-hero-label{display:flex;align-items:center;gap:7px;font-family:'IBM Plex Mono';font-size:11px;text-transform:uppercase;letter-spacing:1.5px;color:var(--dim);}
.pd-hero-val{font-family:'IBM Plex Mono';font-weight:600;font-size:clamp(34px,8vw,58px);letter-spacing:-2px;line-height:1;}
.pd-hero-divider{width:1px;align-self:stretch;background:var(--line);}
.pd-hero-foot{margin-top:30px;font-family:'IBM Plex Mono';font-size:11px;color:var(--dim);position:relative;}
.pd-hero-link{color:var(--cyan);cursor:pointer;text-decoration:underline;}
.pd-chart{margin-top:26px;border-top:1px solid var(--line);padding-top:20px;}
.pd-chart-top{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:10px;}
.pd-chart-label{display:inline-flex;align-items:center;gap:7px;font-family:'IBM Plex Mono';font-size:11px;text-transform:uppercase;letter-spacing:1.5px;color:var(--dim);}
.pd-chart-val{font-family:'IBM Plex Mono';font-weight:600;font-size:clamp(18px,4vw,26px);letter-spacing:-.5px;}
.pd-chart-svg{display:block;width:100%;height:150px;}
.pd-chart-axis{display:flex;justify-content:space-between;font-family:'IBM Plex Mono';font-size:10px;color:var(--dim);margin-top:4px;}
.pd-chart-empty{margin-top:26px;border-top:1px solid var(--line);padding-top:20px;display:flex;align-items:center;justify-content:center;gap:8px;font-family:'IBM Plex Mono';font-size:12px;color:var(--dim);}
.pd-login{background:var(--panel);border:1px solid var(--line);border-radius:18px;width:100%;max-width:380px;padding:24px;animation:rise .25s ease both;}
.pd-login-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;font-family:'Bricolage Grotesque';font-weight:800;font-size:18px;}
.pd-login-head span{display:inline-flex;align-items:center;gap:8px;}
.pd-login-head button{background:none;border:none;color:var(--dim);cursor:pointer;}
.pd-login-head button:hover{color:var(--ink);}
@media(max-width:560px){.pd-hero-divider{display:none;}.pd-hero-grid{gap:26px;}}
.pd-stat{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px 16px;}
.pd-stat-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;}
.pd-stat-label{font-size:11px;color:var(--dim);text-transform:uppercase;letter-spacing:1px;font-family:'IBM Plex Mono';}
.pd-stat-val{font-family:'IBM Plex Mono';font-weight:600;font-size:22px;letter-spacing:-.5px;}
.pd-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:16px;}
.pd-card{background:linear-gradient(160deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:16px;padding:18px;display:flex;flex-direction:column;gap:13px;transition:.2s;animation:rise .4s ease both;}
.pd-card:hover{border-color:#2c3a4d;transform:translateY(-2px);box-shadow:0 12px 30px rgba(0,0,0,.4);}
@keyframes rise{from{opacity:0;transform:translateY(10px);}to{opacity:1;transform:none;}}
.pd-card-head{display:flex;justify-content:space-between;align-items:flex-start;gap:10px;}
.pd-firm{font-family:'Bricolage Grotesque';font-weight:800;font-size:19px;letter-spacing:-.4px;}
.pd-label{color:var(--dim);font-size:12.5px;margin-top:2px;}
.pd-badge{display:inline-flex;align-items:center;gap:5px;font-family:'IBM Plex Mono';font-size:10px;font-weight:600;letter-spacing:.5px;padding:5px 9px;border-radius:7px;white-space:nowrap;}
.pd-balance{display:flex;justify-content:space-between;align-items:flex-end;padding-bottom:4px;border-bottom:1px dashed var(--line);}
.pd-balance-num{font-family:'IBM Plex Mono';font-weight:600;font-size:30px;letter-spacing:-1px;}
.pd-pnl{font-family:'IBM Plex Mono';font-size:13px;font-weight:500;margin-top:3px;}
.pd-phase-tag{font-family:'IBM Plex Mono';font-size:10px;color:var(--dim);text-transform:uppercase;letter-spacing:.5px;border:1px solid var(--line);padding:3px 7px;border-radius:6px;text-align:right;}
.pd-bar-wrap{display:flex;flex-direction:column;gap:5px;}
.pd-bar-top{display:flex;justify-content:space-between;font-family:'IBM Plex Mono';font-size:11px;color:var(--mid);gap:8px;}
.pd-trail{color:var(--cyan);font-size:9px;text-transform:uppercase;letter-spacing:.5px;border:1px solid rgba(255,255,11,.3);padding:1px 4px;border-radius:4px;margin-left:4px;}
.pd-bar-track{height:7px;background:#0a0f16;border-radius:99px;overflow:hidden;border:1px solid var(--line);}
.pd-gauges{display:flex;justify-content:center;gap:10px;margin:2px 0 10px;}
.pd-gauge{background:#0a0f16;border:1px solid var(--line);border-radius:12px;padding:14px 22px 12px;text-align:center;min-width:160px;}
.pd-gauge-label{font-family:'IBM Plex Mono';font-size:9.5px;text-transform:uppercase;letter-spacing:1px;color:var(--dim);margin-bottom:8px;}
.pd-gauge-ring{position:relative;width:88px;height:88px;margin:0 auto;}
.pd-gauge-ring svg{width:100%;height:100%;display:block;}
.pd-gauge-pct{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-family:'IBM Plex Mono';font-weight:600;font-size:19px;letter-spacing:-.5px;}
.pd-gauge-amt{margin-top:9px;font-family:'IBM Plex Mono';font-size:10.5px;color:var(--dim);}
.pd-gauge-amt b{color:var(--ink);font-weight:600;}
.pd-gauge-foot{font-family:'IBM Plex Mono';font-size:10px;color:var(--dim);text-align:center;margin:-2px 0 14px;}
.pd-bar-fill{height:100%;border-radius:99px;transition:width .5s ease;}
.pd-rules{display:grid;grid-template-columns:1fr 1fr;gap:11px;background:#0a0f16;border:1px solid var(--line);border-radius:11px;padding:12px;}
.pd-rule{display:flex;align-items:flex-start;gap:8px;}
.pd-rule-k{font-size:10px;color:var(--dim);text-transform:uppercase;letter-spacing:.5px;font-family:'IBM Plex Mono';}
.pd-rule-v{font-family:'IBM Plex Mono';font-size:14px;font-weight:500;}
.pd-rule-sub{font-family:'IBM Plex Mono';font-size:9.5px;color:var(--dim);margin-top:1px;}
.pd-payout{display:flex;justify-content:space-between;align-items:center;border:1px solid var(--line);border-radius:11px;padding:11px 13px;gap:8px;}
.pd-payout-k{font-size:10px;color:var(--dim);text-transform:uppercase;letter-spacing:.5px;font-family:'IBM Plex Mono';}
.pd-payout-v{font-family:'IBM Plex Mono';font-size:16px;font-weight:600;margin-top:3px;}
.pd-thresh{font-size:10px;color:var(--dim);font-weight:400;}
.pd-payout-status{font-family:'IBM Plex Mono';font-size:10px;font-weight:600;letter-spacing:.5px;padding:5px 9px;border-radius:7px;white-space:nowrap;}
.pd-reasons{display:flex;flex-direction:column;gap:5px;}
.pd-reason{display:flex;align-items:center;gap:6px;font-size:11.5px;color:var(--amber);font-family:'IBM Plex Mono';}
.pd-reason svg{flex-shrink:0;color:var(--amber);}
.pd-actions{display:flex;gap:8px;margin-top:2px;}
.pd-actions button{display:inline-flex;align-items:center;justify-content:center;gap:6px;background:transparent;border:1px solid var(--line);color:var(--mid);font-family:'IBM Plex Sans';font-size:13px;padding:8px;border-radius:8px;cursor:pointer;transition:.15s;}
.pd-actions button:first-child{flex:1;}
.pd-actions button:hover{border-color:var(--dim);color:var(--ink);}
.pd-actions .pd-del:hover{border-color:var(--red);color:var(--red);}
.pd-confirm-del{align-items:center;}
.pd-confirm-txt{display:inline-flex;align-items:center;gap:6px;flex:1;font-family:'IBM Plex Mono';font-size:12px;color:var(--amber);}
.pd-confirm-del .pd-del-yes{flex:0 0 auto;background:rgba(248,81,73,.14);border:1px solid rgba(248,81,73,.4);color:var(--red);}
.pd-confirm-del .pd-del-yes:hover{background:rgba(248,81,73,.24);border-color:rgba(248,81,73,.5);color:var(--red);}
.pd-pay-add button:disabled{opacity:.4;cursor:not-allowed;}
.pd-pay-confirm{margin-top:11px;background:rgba(210,153,34,.08);border:1px solid rgba(210,153,34,.3);border-radius:9px;padding:12px;}
.pd-pay-confirm>span{display:flex;align-items:flex-start;gap:7px;font-family:'IBM Plex Mono';font-size:12px;color:var(--amber);line-height:1.5;}
.pd-pay-confirm>span svg{flex-shrink:0;margin-top:1px;}
.pd-pay-confirm-btns{display:flex;gap:8px;margin-top:11px;}
.pd-pay-yes{background:rgba(255,255,11,.14);border:1px solid rgba(255,255,11,.4);color:var(--cyan);font-family:'IBM Plex Sans';font-size:12.5px;padding:7px 14px;border-radius:8px;cursor:pointer;}
.pd-pay-yes:hover{background:rgba(255,255,11,.24);}
.pd-pay-no{background:transparent;border:1px solid var(--line);color:var(--mid);font-family:'IBM Plex Sans';font-size:12.5px;padding:7px 14px;border-radius:8px;cursor:pointer;}
.pd-pay-no:hover{border-color:var(--dim);color:var(--ink);}
.pd-empty{text-align:center;padding:70px 20px;color:var(--mid);background:var(--panel);border:1px dashed var(--line);border-radius:16px;}
.pd-empty-title{font-family:'Bricolage Grotesque';font-weight:800;font-size:22px;color:var(--ink);margin-bottom:8px;}
.pd-empty p{max-width:420px;margin:0 auto 20px;font-size:14px;line-height:1.5;}
.pd-foot{margin-top:34px;text-align:center;color:var(--dim);font-size:11px;font-family:'IBM Plex Mono';line-height:1.6;}
.pd-modal-bg{position:fixed;inset:0;background:rgba(3,6,10,.78);backdrop-filter:blur(5px);z-index:50;display:flex;align-items:center;justify-content:center;padding:16px;animation:fade .2s ease;}
@keyframes fade{from{opacity:0;}to{opacity:1;}}
.pd-modal{background:var(--panel);border:1px solid var(--line);border-radius:18px;width:100%;max-width:660px;max-height:90vh;overflow-y:auto;animation:rise .25s ease both;}
.pd-modal-head{display:flex;justify-content:space-between;align-items:center;padding:18px 20px;border-bottom:1px solid var(--line);font-family:'Bricolage Grotesque';font-weight:800;font-size:18px;position:sticky;top:0;background:var(--panel);z-index:2;}
.pd-modal-head button{background:none;border:none;color:var(--dim);cursor:pointer;}.pd-modal-head button:hover{color:var(--ink);}
.pd-form{padding:20px;display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.pd-field{display:flex;flex-direction:column;gap:6px;}.pd-field-full{grid-column:1/-1;}
.pd-field-label{font-size:11px;color:var(--mid);text-transform:uppercase;letter-spacing:.5px;font-family:'IBM Plex Mono';display:flex;justify-content:space-between;gap:6px;}
.pd-field-label em{font-style:normal;color:var(--dim);text-transform:none;letter-spacing:0;font-size:10px;}
.pd-field input,.pd-field select{background:#0a0f16;border:1px solid var(--line);color:var(--ink);font-family:'IBM Plex Mono';font-size:14px;padding:10px 12px;border-radius:9px;outline:none;transition:.15s;width:100%;}
.pd-field input:focus,.pd-field select:focus{border-color:var(--cyan);}
.pd-ruleset{margin:0 20px 20px;background:#0a0f16;border:1px solid var(--line);border-radius:11px;padding:14px;}
.pd-ruleset-h{display:flex;align-items:center;gap:6px;font-family:'IBM Plex Mono';font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--cyan);margin-bottom:10px;}
.pd-ruleset-item{font-size:12px;color:var(--mid);line-height:1.5;padding-left:14px;position:relative;margin-bottom:6px;}
.pd-ruleset-item:before{content:"▹";position:absolute;left:0;color:var(--dim);}
.pd-modal-foot{display:flex;justify-content:flex-end;gap:10px;padding:16px 20px;border-top:1px solid var(--line);position:sticky;bottom:0;background:var(--panel);}
.pd-log{margin:0 20px 16px;background:#0a0f16;border:1px solid var(--line);border-radius:11px;padding:14px;}
.pd-log-head{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:11px;flex-wrap:wrap;}
.pd-log-title{display:flex;align-items:center;gap:6px;font-family:'IBM Plex Mono';font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--cyan);}
.pd-log-meta{display:flex;gap:10px;font-family:'IBM Plex Mono';font-size:12px;font-weight:600;}
.pd-log-meta .pd-ok{color:var(--green);}.pd-log-meta .pd-warn{color:var(--amber);}
.pd-log-add{display:flex;gap:8px;}
.pd-log-add input{flex:1;background:#080b10;border:1px solid var(--line);color:var(--ink);font-family:'IBM Plex Mono';font-size:13px;padding:9px 11px;border-radius:8px;outline:none;}
.pd-log-add input:focus{border-color:var(--cyan);}
.pd-log-add button{display:inline-flex;align-items:center;gap:5px;background:rgba(255,255,11,.12);color:var(--cyan);border:1px solid rgba(255,255,11,.3);font-family:'IBM Plex Sans';font-size:13px;padding:0 13px;border-radius:8px;cursor:pointer;white-space:nowrap;transition:.15s;}
.pd-log-add button:hover{background:rgba(255,255,11,.2);}
.pd-log-list{display:flex;flex-direction:column;gap:6px;margin-top:11px;}
.pd-log-row{display:flex;align-items:center;gap:10px;font-family:'IBM Plex Mono';font-size:13px;background:#080b10;border:1px solid var(--line);border-radius:8px;padding:7px 11px;}
.pd-log-day{color:var(--dim);font-size:11px;width:46px;}
.pd-log-amt{font-weight:600;flex:1;}
.pd-log-tag{font-size:9.5px;text-transform:uppercase;letter-spacing:.5px;border:1px solid var(--line);padding:2px 7px;border-radius:5px;}
.pd-log-row button{background:none;border:none;color:var(--dim);cursor:pointer;display:flex;padding:2px;}
.pd-log-row button:hover{color:var(--red);}
.pd-log-note{font-family:'IBM Plex Mono';font-size:10px;color:var(--dim);line-height:1.5;margin-top:11px;}
.pd-cal-nav{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;}
.pd-cal-nav span{font-family:'IBM Plex Mono';font-size:13px;font-weight:600;color:var(--ink);}
.pd-cal-nav button{background:#080b10;border:1px solid var(--line);color:var(--mid);width:30px;height:30px;border-radius:8px;cursor:pointer;font-size:16px;line-height:1;transition:.15s;}
.pd-cal-nav button:hover{border-color:var(--cyan);color:var(--cyan);}
.pd-cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:5px;}
.pd-cal-dow{text-align:center;font-family:'IBM Plex Mono';font-size:10px;color:var(--dim);padding-bottom:3px;}
.pd-cal-empty{aspect-ratio:1;}
.pd-cal-cell{position:relative;aspect-ratio:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;background:#080b10;border:1px solid var(--line);border-radius:8px;cursor:pointer;padding:2px;transition:.12s;}
.pd-cal-cell:hover{border-color:var(--cyan);}
.pd-cal-cell.future{opacity:.3;cursor:not-allowed;}
.pd-cal-cell.future:hover{border-color:var(--line);}
.pd-cal-cell.today{border-color:var(--dim);}
.pd-cal-cell.sel{border-color:var(--cyan);box-shadow:0 0 0 1px var(--cyan);}
.pd-cal-cell.pos{background:rgba(63,185,80,.07);}
.pd-cal-cell.neg{background:rgba(248,81,73,.07);}
.pd-cal-num{font-family:'IBM Plex Mono';font-size:12px;color:var(--mid);line-height:1;}
.pd-cal-amt{font-family:'IBM Plex Mono';font-size:9.5px;font-weight:600;line-height:1;}
.pd-cal-dot{position:absolute;top:4px;right:4px;width:5px;height:5px;border-radius:50%;background:var(--green);}
.pd-cal-editor{margin-top:12px;padding-top:12px;border-top:1px dashed var(--line);}
.pd-cal-editor-date{font-family:'IBM Plex Mono';font-size:11px;color:var(--cyan);text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px;}
.pd-cal-clear{flex:0 0 auto !important;background:transparent !important;border:1px solid var(--line) !important;color:var(--dim) !important;padding:0 11px !important;}
.pd-cal-clear:hover{border-color:var(--red) !important;color:var(--red) !important;background:transparent !important;}
.pd-reset-row{display:flex;align-items:center;gap:8px;margin-top:12px;padding-top:12px;border-top:1px solid var(--line);flex-wrap:wrap;}
.pd-reset-btn{display:inline-flex;align-items:center;gap:6px;background:transparent;border:1px solid var(--line);color:var(--mid);font-family:'IBM Plex Sans';font-size:12.5px;padding:7px 12px;border-radius:8px;cursor:pointer;transition:.15s;}
.pd-reset-btn:hover{border-color:var(--red);color:var(--red);}
.pd-reset-btn:disabled{opacity:.4;cursor:not-allowed;}
.pd-reset-btn:disabled:hover{border-color:var(--line);color:var(--mid);}
.pd-reset-q{font-family:'IBM Plex Mono';font-size:12px;color:var(--amber);}
.pd-reset-yes{background:rgba(248,81,73,.14);border:1px solid rgba(248,81,73,.4);color:var(--red);font-family:'IBM Plex Sans';font-size:12.5px;padding:7px 12px;border-radius:8px;cursor:pointer;}
.pd-reset-yes:hover{background:rgba(248,81,73,.24);}
.pd-reset-no{background:transparent;border:1px solid var(--line);color:var(--mid);font-family:'IBM Plex Sans';font-size:12.5px;padding:7px 12px;border-radius:8px;cursor:pointer;}
.pd-reset-no:hover{border-color:var(--dim);color:var(--ink);}
.pd-cal-cell.past{opacity:.4;}
.pd-cal-cell.past .pd-cal-amt{filter:saturate(.5);}
.pd-live{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:0 20px 16px;}
.pd-live-cell{background:#0a0f16;border:1px solid var(--line);border-radius:10px;padding:11px 12px;}
.pd-live-label{font-family:'IBM Plex Mono';font-size:9.5px;text-transform:uppercase;letter-spacing:.5px;color:var(--dim);}
.pd-live-val{font-family:'IBM Plex Mono';font-size:17px;font-weight:600;margin-top:4px;letter-spacing:-.3px;}
.pd-live-sub{font-family:'IBM Plex Mono';font-size:9.5px;color:var(--dim);margin-top:2px;}
.pd-pay-add{display:flex;gap:8px;flex-wrap:wrap;}
.pd-pay-add input[type=date]{flex:0 0 auto;background:#080b10;border:1px solid var(--line);color:var(--ink);font-family:'IBM Plex Mono';font-size:13px;padding:9px 11px;border-radius:8px;outline:none;}
.pd-pay-add input[type=number]{flex:1;min-width:120px;background:#080b10;border:1px solid var(--line);color:var(--ink);font-family:'IBM Plex Mono';font-size:13px;padding:9px 11px;border-radius:8px;outline:none;}
.pd-pay-add input:focus{border-color:var(--cyan);}
.pd-pay-add button{display:inline-flex;align-items:center;gap:5px;background:rgba(255,255,11,.12);color:var(--cyan);border:1px solid rgba(255,255,11,.3);font-family:'IBM Plex Sans';font-size:13px;padding:0 13px;border-radius:8px;cursor:pointer;white-space:nowrap;}
.pd-pay-add button:hover{background:rgba(255,255,11,.2);}
@media(max-width:560px){.pd-live{grid-template-columns:1fr 1fr;}.pd-form{grid-template-columns:1fr;}.pd-grid{grid-template-columns:1fr;}}
`;
